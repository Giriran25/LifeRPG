import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export type AiSuggestion = {
  title: string;
  category: string;
  difficulty: "easy" | "medium" | "hard" | "epic";
  reason: string;
};

export type AiGuide = {
  motivation: string;
  insight: string;
  suggestions: AiSuggestion[];
  generated_at: string;
  /** True when the guide came from stored data rules instead of the AI model. */
  fallback: boolean;
};

const DIFFICULTIES = ["easy", "medium", "hard", "epic"] as const;

function daysAgoISO(today: string, days: number) {
  const d = new Date(`${today}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() - days);
  return d.toISOString().slice(0, 10);
}

/**
 * Builds the structured productivity profile the coach reasons over.
 * Only real, stored data enters this object — the model never sees raw dumps
 * and is never asked to invent statistics.
 */
async function buildUserProfile(
  supabase: Parameters<typeof Object.keys>[0] extends never ? never : any,
  userId: string,
) {
  const { data: todayRow } = await supabase.rpc("user_today", { p_user: userId });
  const today: string = (todayRow as string) ?? new Date().toISOString().slice(0, 10);

  const [profileRes, completionsRes, questsRes, goalsRes, pendingRes] = await Promise.all([
    supabase.from("profiles").select("*").eq("id", userId).maybeSingle(),
    supabase
      .from("quest_completions")
      .select("day, category, xp_awarded, completed_at, quest_id")
      .eq("user_id", userId)
      .gte("day", daysAgoISO(today, 29)),
    supabase
      .from("quests")
      .select("title, category, difficulty, status, quest_date")
      .eq("user_id", userId)
      .gte("quest_date", daysAgoISO(today, 29)),
    supabase.from("goals").select("title, emoji, target_quests, completed_quests").eq("user_id", userId),
    supabase
      .from("quests")
      .select("title, category, difficulty, quest_date")
      .eq("user_id", userId)
      .eq("status", "pending")
      .lt("quest_date", today),
  ]);

  const completions = (completionsRes.data ?? []) as Array<{
    day: string;
    category: string;
    completed_at: string;
  }>;
  const quests = (questsRes.data ?? []) as Array<{
    title: string;
    category: string;
    difficulty: string;
    status: string;
    quest_date: string;
  }>;

  const byCategory = new Map<string, number>();
  const byHour = new Map<number, number>();
  const byTitle = new Map<string, Set<string>>();
  for (const c of completions) {
    byCategory.set(c.category, (byCategory.get(c.category) ?? 0) + 1);
    const h = new Date(c.completed_at).getHours();
    byHour.set(h, (byHour.get(h) ?? 0) + 1);
  }
  for (const q of quests.filter((q) => q.status === "completed")) {
    const set = byTitle.get(q.title) ?? new Set<string>();
    set.add(q.quest_date);
    byTitle.set(q.title, set);
  }

  const attempted = quests.length;
  const done = quests.filter((q) => q.status === "completed").length;
  const missed = quests.filter((q) => q.status !== "completed" && q.quest_date < today);
  const peakHour = [...byHour.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] ?? null;
  const lastByCategory = new Map<string, string>();
  for (const c of completions) {
    const prev = lastByCategory.get(c.category);
    if (!prev || c.day > prev) lastByCategory.set(c.category, c.day);
  }

  return {
    today,
    profile: profileRes.data,
    level: profileRes.data?.level ?? 1,
    xp: profileRes.data?.xp ?? 0,
    current_streak: profileRes.data?.current_streak ?? 0,
    completion_rate: attempted > 0 ? Math.round((done / attempted) * 100) : null,
    completions_30d: completions.length,
    quests_done_today: completions.filter((c) => c.day === today).length,
    avg_daily_quests: Math.round((completions.length / 30) * 10) / 10,
    categories: [...byCategory.entries()]
      .sort((a, b) => b[1] - a[1])
      .map(([category, count]) => ({
        category,
        count,
        last_done: lastByCategory.get(category) ?? null,
      })),
    routines: [...byTitle.entries()]
      .filter(([, days]) => days.size >= 3)
      .sort((a, b) => b[1].size - a[1].size)
      .slice(0, 5)
      .map(([title, days]) => ({ title, days: days.size })),
    missed_recent: missed.slice(0, 5).map((q) => ({
      title: q.title,
      category: q.category,
      date: q.quest_date,
    })),
    goals: goalsRes.data ?? [],
    unfinished_from_previous_days: (pendingRes.data ?? []).length,
    peak_hour: peakHour,
    hardest_completed: quests
      .filter((q) => q.status === "completed")
      .some((q) => q.difficulty === "hard" || q.difficulty === "epic"),
  };
}

/** Deterministic coach built only from stored data. Used when AI is unavailable. */
function ruleBasedGuide(p: Awaited<ReturnType<typeof buildUserProfile>>): AiGuide {
  const suggestions: AiSuggestion[] = [];
  for (const r of p.routines.slice(0, 2)) {
    suggestions.push({
      title: r.title,
      category: p.categories[0]?.category ?? "General",
      difficulty: "medium",
      reason: `You completed this on ${r.days} different days in the last 30 days.`,
    });
  }
  const stale = p.categories.find(
    (c) => c.last_done && c.last_done < daysAgoISO(p.today, 5),
  );
  if (stale) {
    suggestions.push({
      title: `A short ${stale.category} session`,
      category: stale.category,
      difficulty: "easy",
      reason: `Your last ${stale.category} quest was on ${stale.last_done}.`,
    });
  }
  if (suggestions.length === 0) {
    suggestions.push({
      title: "Pick one thing that matters today",
      category: "General",
      difficulty: "easy",
      reason: "You have no history yet — start with one small quest.",
    });
  }

  const motivation =
    p.current_streak > 1
      ? `You're on a ${p.current_streak}-day streak. One quest today keeps it alive.`
      : p.unfinished_from_previous_days > 0
        ? "Yesterday didn't go as planned, and that's fine. Recover with one small quest."
        : "Your adventure starts with a single quest. Choose one and begin.";

  const insight =
    p.peak_hour !== null && p.completions_30d >= 5
      ? `You complete most quests around ${p.peak_hour}:00. Plan your hardest quest near then.`
      : "Complete a few more quests and your productivity patterns will show up here.";

  return {
    motivation,
    insight,
    suggestions: suggestions.slice(0, 4),
    generated_at: new Date().toISOString(),
    fallback: true,
  };
}

async function callCoach(
  profile: Awaited<ReturnType<typeof buildUserProfile>>,
): Promise<AiGuide | null> {
  const apiKey = process.env["LOVABLE_API_KEY"];
  if (!apiKey) return null;

  const system = `You are the AI productivity coach inside a gamified life RPG.
Rules:
- Use ONLY the JSON data provided. Never invent statistics, streaks or completions.
- Reference concrete numbers from the data when you explain a recommendation.
- Be warm, practical and never shaming. Never encourage overwork or unrealistic workloads.
- If the user has repeatedly failed large quests, recommend smaller versions instead.
- Return between 2 and 4 suggestions, ranked most useful first.
Respond ONLY with JSON of shape:
{"motivation": string, "insight": string, "suggestions": [{"title": string, "category": string, "difficulty": "easy"|"medium"|"hard"|"epic", "reason": string}]}
Keep motivation and insight under 240 characters each. Titles must be concrete and doable today.`;

  const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Lovable-API-Key": apiKey,
      "X-Lovable-AIG-SDK": "fetch",
    },
    body: JSON.stringify({
      model: "google/gemini-3.8-flash",
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: system },
        { role: "user", content: JSON.stringify(profile) },
      ],
    }),
  });

  if (!res.ok) {
    const body = await res.text();
    console.error("[ai-coach]", res.status, body.slice(0, 400));
    if (res.status === 402 || res.status === 403) {
      throw new Error(
        "AI coaching is unavailable right now: the workspace AI credits or permissions need attention.",
      );
    }
    return null;
  }

  const json = (await res.json()) as {
    choices?: Array<{ message?: { content?: string } }>;
  };
  const content = json.choices?.[0]?.message?.content;
  if (!content) return null;

  const parsed = z
    .object({
      motivation: z.string().max(400),
      insight: z.string().max(400),
      suggestions: z
        .array(
          z.object({
            title: z.string().max(120),
            category: z.string().max(40),
            difficulty: z.enum(DIFFICULTIES).catch("medium"),
            reason: z.string().max(240),
          }),
        )
        .min(1)
        .max(5),
    })
    .safeParse(JSON.parse(content));
  if (!parsed.success) return null;

  return {
    ...parsed.data,
    suggestions: parsed.data.suggestions.slice(0, 4),
    generated_at: new Date().toISOString(),
    fallback: false,
  };
}

/** Cached once per day per player; refresh forces a new generation. */
export const getAiGuide = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ refresh: z.boolean().default(false) }).parse(input ?? {}),
  )
  .handler(async ({ data, context }): Promise<AiGuide> => {
    const { supabase, userId } = context;
    const profile = await buildUserProfile(supabase, userId);

    if (!data.refresh) {
      const { data: cached } = await supabase
        .from("ai_recommendations")
        .select("payload")
        .eq("user_id", userId)
        .eq("day", profile.today)
        .maybeSingle();
      if (cached?.payload) return cached.payload as unknown as AiGuide;
    }

    let guide: AiGuide | null = null;
    try {
      guide = await callCoach(profile);
    } catch (error) {
      console.error("[ai-coach] failed", error);
    }
    const result = guide ?? ruleBasedGuide(profile);

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin
      .from("ai_recommendations")
      .upsert(
        { user_id: userId, day: profile.today, payload: result as never },
        { onConflict: "user_id,day" },
      );

    return result;
  });

export type CoachMessage = { role: "user" | "assistant"; content: string };

/** Conversational coach: answers using the player's real stored data only. */
export const chatWithCoach = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        messages: z
          .array(
            z.object({
              role: z.enum(["user", "assistant"]),
              content: z.string().trim().min(1).max(1200),
            }),
          )
          .min(1)
          .max(24),
      })
      .parse(input),
  )
  .handler(async ({ data, context }): Promise<{ reply: string; fallback: boolean }> => {
    const { supabase, userId } = context;
    const profile = await buildUserProfile(supabase, userId);

    const { data: pending } = await supabase
      .from("quests")
      .select("title, category, difficulty, quest_date")
      .eq("user_id", userId)
      .eq("status", "pending")
      .lte("quest_date", profile.today)
      .order("quest_date", { ascending: true })
      .limit(10);

    const unfinished = (pending ?? []) as Array<{
      title: string;
      category: string;
      quest_date: string;
    }>;
    const overdue = unfinished.filter((q) => q.quest_date < profile.today);

    const apiKey = process.env["LOVABLE_API_KEY"];
    if (!apiKey) {
      const reply = overdue.length
        ? `You still have ${overdue.length} quest${overdue.length === 1 ? "" : "s"} waiting from earlier days — starting with “${overdue[0]!.title}”. Knock one out and the momentum comes back.`
        : `Level ${profile.level}, ${profile.current_streak}-day streak. ${unfinished.length ? `Today's next quest: “${unfinished[0]!.title}”.` : "Nothing pending right now — add one quest that matters today."}`;
      return { reply, fallback: true };
    }

    const system = `You are the personal coach inside Life RPG, a gamified productivity app.
Rules:
- Use ONLY the player's JSON data below. Never invent statistics, streaks, or completions.
- Be warm, short (max 90 words), and motivating. No shame, no guilt, no unhealthy workloads.
- When there are unfinished or overdue quests, gently remind the player of one specific quest by name and suggest one next step.
- Speak in RPG flavour (quests, XP, streak) without being cheesy.
Player data: ${JSON.stringify({
      level: profile.level,
      xp: profile.xp,
      current_streak: profile.current_streak,
      completion_rate: profile.completion_rate,
      quests_done_today: profile.quests_done_today,
      categories: profile.categories.slice(0, 5),
      routines: profile.routines,
      goals: profile.goals,
      peak_hour: profile.peak_hour,
      unfinished_quests: unfinished,
      overdue_quests: overdue,
    })}`;

    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Lovable-API-Key": apiKey,
        "X-Lovable-AIG-SDK": "fetch",
      },
      body: JSON.stringify({
        model: "google/gemini-3.8-flash",
        messages: [{ role: "system", content: system }, ...data.messages],
      }),
    });

    if (!res.ok) {
      const body = await res.text();
      console.error("[coach-chat]", res.status, body.slice(0, 400));
      if (res.status === 429)
        throw new Error("Your coach is catching their breath — try again in a moment.");
      if (res.status === 402 || res.status === 403)
        throw new Error("AI coaching is unavailable: the workspace AI credits need attention.");
      throw new Error("The coach couldn't answer right now.");
    }

    const json = (await res.json()) as { choices?: Array<{ message?: { content?: string } }> };
    const reply = json.choices?.[0]?.message?.content?.trim();
    if (!reply) throw new Error("The coach couldn't answer right now.");
    return { reply, fallback: false };
  });
