import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const getCommunities = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const [communities, memberships, categories] = await Promise.all([
      supabase.from("communities").select("*").order("member_count", { ascending: false }),
      supabase.from("community_members").select("community_id, role").eq("user_id", userId),
      supabase
        .from("quest_completions")
        .select("category")
        .eq("user_id", userId)
        .order("completed_at", { ascending: false })
        .limit(120),
    ]);

    const counts = new Map<string, number>();
    for (const row of categories.data ?? [])
      counts.set(row.category, (counts.get(row.category) ?? 0) + 1);
    const top = [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 2);

    const suggestionMap: Record<string, string[]> = {
      DSA: ["dsa-warriors", "placement-prep"],
      Coding: ["dsa-warriors", "startup-builders"],
      Fitness: ["fitness-squad"],
      Reading: ["book-club"],
      Study: ["placement-prep", "productivity-masters"],
      Career: ["placement-prep", "startup-builders"],
      Mind: ["productivity-masters"],
    };
    const joined = new Set((memberships.data ?? []).map((m) => m.community_id));
    const suggestedSlugs = new Set(top.flatMap(([cat]) => suggestionMap[cat] ?? []));
    const suggested = (communities.data ?? []).filter(
      (c) => suggestedSlugs.has(c.slug) && !joined.has(c.id),
    );

    return {
      communities: communities.data ?? [],
      memberships: memberships.data ?? [],
      suggested,
      basis: top.map(([category, count]) => ({ category, count })),
    };
  });

export const getCommunityDetail = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const [community, posts, challenges, board, membership] = await Promise.all([
      supabase.from("communities").select("*").eq("id", data.id).maybeSingle(),
      supabase
        .from("community_posts")
        .select("*")
        .eq("community_id", data.id)
        .order("created_at", { ascending: false })
        .limit(30),
      supabase
        .from("community_challenges")
        .select("*")
        .eq("community_id", data.id)
        .order("ends_on", { ascending: true }),
      supabase.rpc("get_community_leaderboard", { p_community_id: data.id }),
      supabase
        .from("community_members")
        .select("role")
        .eq("community_id", data.id)
        .eq("user_id", userId)
        .maybeSingle(),
    ]);

    const postIds = (posts.data ?? []).map((p) => p.id);
    const authorIds = [...new Set((posts.data ?? []).map((p) => p.user_id))];
    const [reactions, authors, participants] = await Promise.all([
      postIds.length
        ? supabase.from("post_reactions").select("post_id, user_id, emoji").in("post_id", postIds)
        : Promise.resolve({ data: [] as Array<{ post_id: string; user_id: string; emoji: string }> }),
      authorIds.length
        ? supabase
            .from("profiles")
            .select("id, display_name, avatar_emoji, level, title")
            .in("id", authorIds)
        : Promise.resolve({
            data: [] as Array<{
              id: string;
              display_name: string;
              avatar_emoji: string;
              level: number;
              title: string;
            }>,
          }),
      supabase.from("challenge_participants").select("*").eq("user_id", userId),
    ]);

    return {
      community: community.data,
      isMember: Boolean(membership.data),
      posts: posts.data ?? [],
      authors: authors.data ?? [],
      reactions: reactions.data ?? [],
      challenges: challenges.data ?? [],
      myParticipation: participants.data ?? [],
      leaderboard: board.data ?? [],
      me: userId,
    };
  });

export const joinCommunity = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.rpc("join_community", { p_community_id: data.id });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const leaveCommunity = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.rpc("leave_community", { p_community_id: data.id });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const createCommunity = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        name: z.string().trim().min(3).max(40),
        emoji: z.string().max(8).default("🛡️"),
        description: z.string().trim().max(200).default(""),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const slug =
      data.name
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-|-$/g, "")
        .slice(0, 40) || `guild-${Date.now()}`;
    const { data: community, error } = await context.supabase
      .from("communities")
      .insert({ ...data, slug, created_by: context.userId })
      .select()
      .single();
    if (error) throw new Error(error.message);
    await context.supabase.rpc("join_community", { p_community_id: community.id });
    return { community };
  });

export const createPost = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        communityId: z.string().uuid(),
        body: z.string().trim().min(2).max(600),
        kind: z.enum(["update", "achievement", "tip", "question"]).default("update"),
        meta: z.record(z.unknown()).default({}),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { data: post, error } = await context.supabase
      .from("community_posts")
      .insert({
        community_id: data.communityId,
        user_id: context.userId,
        body: data.body,
        kind: data.kind,
        meta: data.meta as never,
      })
      .select()
      .single();
    if (error) throw new Error(error.message);
    return { post };
  });

export const toggleReaction = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ postId: z.string().uuid(), emoji: z.string().min(1).max(8) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: existing } = await supabase
      .from("post_reactions")
      .select("post_id")
      .eq("post_id", data.postId)
      .eq("user_id", userId)
      .eq("emoji", data.emoji)
      .maybeSingle();
    if (existing) {
      await supabase
        .from("post_reactions")
        .delete()
        .eq("post_id", data.postId)
        .eq("user_id", userId)
        .eq("emoji", data.emoji);
      return { reacted: false };
    }
    const { error } = await supabase
      .from("post_reactions")
      .insert({ post_id: data.postId, user_id: userId, emoji: data.emoji });
    if (error) throw new Error(error.message);
    return { reacted: true };
  });

export const createChallenge = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        communityId: z.string().uuid(),
        title: z.string().trim().min(3).max(80),
        description: z.string().trim().max(300).default(""),
        required_quests: z.number().int().min(1).max(500).default(20),
        days: z.number().int().min(1).max(365).default(30),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const ends = new Date();
    ends.setDate(ends.getDate() + data.days);
    const { data: challenge, error } = await context.supabase
      .from("community_challenges")
      .insert({
        community_id: data.communityId,
        title: data.title,
        description: data.description,
        required_quests: data.required_quests,
        ends_on: ends.toISOString().slice(0, 10),
        created_by: context.userId,
      })
      .select()
      .single();
    if (error) throw new Error(error.message);
    return { challenge };
  });

export const joinChallenge = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("challenge_participants")
      .insert({ challenge_id: data.id, user_id: context.userId });
    if (error && !error.message.includes("duplicate")) throw new Error(error.message);
    return { ok: true };
  });
