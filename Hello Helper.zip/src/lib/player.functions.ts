import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { Database } from "@/integrations/supabase/types";

type Profile = Database["public"]["Tables"]["profiles"]["Row"];
type Item = Database["public"]["Tables"]["items"]["Row"];
type UnlockedBadge = { code: string; name: string; emoji: string; description: string; gold_reward: number };

const difficulty = z.enum(["easy", "medium", "hard", "epic"]);

const questInput = z.object({
  title: z.string().trim().min(2).max(120),
  category: z.string().trim().min(1).max(40).default("General"),
  difficulty: difficulty.default("medium"),
  goal_id: z.string().uuid().nullable().optional(),
  source: z.string().max(30).default("manual"),
  recovered_from: z.string().uuid().nullable().optional(),
});

function daysAgoISO(today: string, days: number) {
  const d = new Date(`${today}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() - days);
  return d.toISOString().slice(0, 10);
}

/** The player's authoritative dashboard state. */
export const getPlayerState = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;

    const { data: todayRow } = await supabase.rpc("user_today", { p_user: userId });
    const today = (todayRow as unknown as string) ?? new Date().toISOString().slice(0, 10);

    const [profileRes, questsRes, goalsRes, effectsRes, recentRes] = await Promise.all([
      supabase.from("profiles").select("*").eq("id", userId).maybeSingle(),
      supabase
        .from("quests")
        .select("*")
        .eq("user_id", userId)
        .gte("quest_date", daysAgoISO(today, 14))
        .order("created_at", { ascending: true }),
      supabase.from("goals").select("*").eq("user_id", userId).order("created_at"),
      supabase.from("player_effects").select("*").eq("user_id", userId).maybeSingle(),
      supabase
        .from("quest_completions")
        .select("category, day, xp_awarded, quest_id")
        .eq("user_id", userId)
        .gte("day", daysAgoISO(today, 21)),
    ]);

    // Self-heal: accounts created before the profile trigger (or via an odd path)
    // must still get a character sheet on first load.
    let profile = profileRes.data;
    if (!profile) {
      const created = await supabase
        .from("profiles")
        .insert({ id: userId })
        .select("*")
        .maybeSingle();
      profile = created.data;
    }

    const quests = questsRes.data ?? [];
    const todayQuests = quests.filter((q) => q.quest_date === today);
    const recoveryQuests = quests.filter(
      (q) => q.quest_date < today && q.status === "pending",
    );

    // Recurring routine detection: titles completed on 3+ distinct days recently.
    const completedIds = new Set((recentRes.data ?? []).map((c) => c.quest_id));
    const { data: completedQuests } = await supabase
      .from("quests")
      .select("title, category, difficulty, quest_date")
      .eq("user_id", userId)
      .eq("status", "completed")
      .gte("quest_date", daysAgoISO(today, 21));

    const routineMap = new Map<
      string,
      { title: string; category: string; difficulty: string; days: Set<string> }
    >();
    for (const q of completedQuests ?? []) {
      const key = q.title.toLowerCase();
      const entry = routineMap.get(key) ?? {
        title: q.title,
        category: q.category,
        difficulty: q.difficulty as string,
        days: new Set<string>(),
      };
      entry.days.add(q.quest_date);
      routineMap.set(key, entry);
    }
    const todayTitles = new Set(todayQuests.map((q) => q.title.toLowerCase()));
    const usualQuests = [...routineMap.values()]
      .filter((r) => r.days.size >= 3 && !todayTitles.has(r.title.toLowerCase()))
      .sort((a, b) => b.days.size - a.days.size)
      .slice(0, 4)
      .map((r) => ({
        title: r.title,
        category: r.category,
        difficulty: r.difficulty,
        days: r.days.size,
      }));

    return {
      today,
      profile,
      todayQuests,
      recoveryQuests,
      usualQuests,
      goals: goalsRes.data ?? [],
      effects: effectsRes.data ?? { xp_boost_quests_left: 0, streak_shields: 0 },
      completedIds: [...completedIds].length,
    };
  });

export const createQuests = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ quests: z.array(questInput).min(1).max(10) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: todayRow } = await supabase.rpc("user_today", { p_user: userId });
    const today = (todayRow as unknown as string) ?? new Date().toISOString().slice(0, 10);

    const rows = data.quests.map((q) => ({
      user_id: userId,
      title: q.title,
      category: q.category,
      difficulty: q.difficulty,
      goal_id: q.goal_id ?? null,
      recovered_from: q.recovered_from ?? null,
      source: q.source,
      quest_date: today,
    }));

    const { data: inserted, error } = await supabase.from("quests").insert(rows).select();
    if (error) throw new Error(error.message);

    // A recovered quest replaces the old pending one so it is not surfaced twice.
    const recovered = data.quests.map((q) => q.recovered_from).filter(Boolean) as string[];
    if (recovered.length) {
      await supabase
        .from("quests")
        .update({ status: "skipped" })
        .eq("user_id", userId)
        .in("id", recovered);
    }
    return { quests: inserted ?? [] };
  });

export const completeQuest = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ questId: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { data: result, error } = await context.supabase.rpc("complete_quest", {
      p_quest_id: data.questId,
    });
    if (error) throw new Error(error.message);
    return result as unknown as {
      xp_awarded: number;
      gold_awarded: number;
      leveled_up: boolean;
      previous_level: number;
      new_level: number;
      unlocked: UnlockedBadge[];
      profile: Profile;
    };
  });

export const dismissQuests = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ questIds: z.array(z.string().uuid()).min(1).max(50) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("quests")
      .update({ status: "skipped" })
      .eq("user_id", context.userId)
      .in("id", data.questIds);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteQuest = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ questId: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("quests")
      .delete()
      .eq("user_id", context.userId)
      .eq("id", data.questId)
      .eq("status", "pending");
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const createGoal = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        title: z.string().trim().min(2).max(80),
        emoji: z.string().max(8).default("🎯"),
        target_quests: z.number().int().min(1).max(1000).default(20),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { data: goal, error } = await context.supabase
      .from("goals")
      .insert({ ...data, user_id: context.userId })
      .select()
      .single();
    if (error) throw new Error(error.message);
    return { goal };
  });

export const updateProfile = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        display_name: z.string().trim().min(2).max(30).optional(),
        avatar_emoji: z.string().max(8).optional(),
        timezone: z.string().max(60).optional(),
        is_public: z.boolean().optional(),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const patch: Database["public"]["Tables"]["profiles"]["Update"] = {};
    if (data.display_name !== undefined) patch.display_name = data.display_name;
    if (data.avatar_emoji !== undefined) patch.avatar_emoji = data.avatar_emoji;
    if (data.timezone !== undefined) patch.timezone = data.timezone;
    if (data.is_public !== undefined) patch.is_public = data.is_public;
    const { data: profile, error } = await context.supabase
      .from("profiles")
      .update(patch)
      .eq("id", context.userId)
      .select()
      .single();
    if (error) throw new Error(error.message);
    return { profile };
  });

/** Heatmap + weekly summary + achievements for the Progress screen. */
export const getProgress = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const { data: todayRow } = await supabase.rpc("user_today", { p_user: userId });
    const today = (todayRow as unknown as string) ?? new Date().toISOString().slice(0, 10);

    const [activityRes, achRes, unlockedRes, weekRes, prevWeekRes, catRes] = await Promise.all([
      supabase
        .from("daily_activity")
        .select("*")
        .eq("user_id", userId)
        .gte("day", daysAgoISO(today, 364)),
      supabase.from("achievements").select("*").order("sort_order"),
      supabase.from("user_achievements").select("code, unlocked_at").eq("user_id", userId),
      supabase
        .from("quest_completions")
        .select("day, category, xp_awarded, completed_at")
        .eq("user_id", userId)
        .gte("day", daysAgoISO(today, 6)),
      supabase
        .from("daily_activity")
        .select("xp_earned, quests_completed")
        .eq("user_id", userId)
        .gte("day", daysAgoISO(today, 13))
        .lte("day", daysAgoISO(today, 7)),
      supabase
        .from("quest_completions")
        .select("category")
        .eq("user_id", userId)
        .gte("day", daysAgoISO(today, 29)),
    ]);

    const week = weekRes.data ?? [];
    const weekXp = week.reduce((s, c) => s + c.xp_awarded, 0);
    const prevWeekXp = (prevWeekRes.data ?? []).reduce((s, d) => s + d.xp_earned, 0);

    const byDay = new Map<string, number>();
    const byCategory = new Map<string, number>();
    const byHour = new Map<number, number>();
    for (const c of week) {
      byDay.set(c.day, (byDay.get(c.day) ?? 0) + 1);
      byCategory.set(c.category, (byCategory.get(c.category) ?? 0) + 1);
      const hour = new Date(c.completed_at).getHours();
      byHour.set(hour, (byHour.get(hour) ?? 0) + 1);
    }
    const bestDay = [...byDay.entries()].sort((a, b) => b[1] - a[1])[0];
    const topCategory = [...byCategory.entries()].sort((a, b) => b[1] - a[1])[0];
    const peakHour = [...byHour.entries()].sort((a, b) => b[1] - a[1])[0];

    const monthCategories = new Map<string, number>();
    for (const c of catRes.data ?? [])
      monthCategories.set(c.category, (monthCategories.get(c.category) ?? 0) + 1);

    return {
      today,
      activity: activityRes.data ?? [],
      achievements: achRes.data ?? [],
      unlocked: unlockedRes.data ?? [],
      week: {
        quests: week.length,
        xp: weekXp,
        bestDay: bestDay ? bestDay[0] : null,
        bestDayCount: bestDay ? bestDay[1] : 0,
        topCategory: topCategory ? topCategory[0] : null,
        peakHour: peakHour ? peakHour[0] : null,
        changePercent: prevWeekXp > 0 ? Math.round(((weekXp - prevWeekXp) / prevWeekXp) * 100) : null,
      },
      monthCategories: [...monthCategories.entries()].map(([category, count]) => ({
        category,
        count,
      })),
    };
  });

export const getDayDetail = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ day: z.string().regex(/^\d{4}-\d{2}-\d{2}$/) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const [completions, activity] = await Promise.all([
      supabase
        .from("quest_completions")
        .select("xp_awarded, gold_awarded, category, quest_id, completed_at")
        .eq("user_id", userId)
        .eq("day", data.day),
      supabase
        .from("daily_activity")
        .select("*")
        .eq("user_id", userId)
        .eq("day", data.day)
        .maybeSingle(),
    ]);
    const ids = (completions.data ?? []).map((c) => c.quest_id);
    const { data: quests } = ids.length
      ? await supabase.from("quests").select("id, title, category, difficulty").in("id", ids)
      : { data: [] as Array<{ id: string; title: string; category: string; difficulty: string }> };
    return {
      day: data.day,
      activity: activity.data,
      quests:
        (completions.data ?? []).map((c) => ({
          ...c,
          title: quests?.find((q) => q.id === c.quest_id)?.title ?? "Quest",
        })) ?? [],
    };
  });

export const getLeaderboard = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ period: z.enum(["week", "month", "all"]).default("all") }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { data: rows, error } = await context.supabase.rpc("get_leaderboard", {
      p_period: data.period,
    });
    if (error) throw new Error(error.message);
    return { rows: rows ?? [], me: context.userId };
  });


export const recordShare = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({ kind: z.string().max(40), platform: z.string().max(40).default("unknown") })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { data: result, error } = await context.supabase.rpc("record_social_share", {
      p_kind: data.kind,
      p_platform: data.platform,
    });
    if (error) throw new Error(error.message);
    return result as unknown as { badge_awarded: boolean };
  });
