export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      achievements: {
        Row: {
          category: string
          code: string
          description: string
          emoji: string
          gold_reward: number
          name: string
          sort_order: number
          threshold: number
        }
        Insert: {
          category: string
          code: string
          description: string
          emoji: string
          gold_reward?: number
          name: string
          sort_order?: number
          threshold?: number
        }
        Update: {
          category?: string
          code?: string
          description?: string
          emoji?: string
          gold_reward?: number
          name?: string
          sort_order?: number
          threshold?: number
        }
        Relationships: []
      }
      ai_recommendations: {
        Row: {
          created_at: string
          day: string
          id: string
          payload: Json
          user_id: string
        }
        Insert: {
          created_at?: string
          day: string
          id?: string
          payload: Json
          user_id: string
        }
        Update: {
          created_at?: string
          day?: string
          id?: string
          payload?: Json
          user_id?: string
        }
        Relationships: []
      }
      challenge_participants: {
        Row: {
          challenge_id: string
          completed_at: string | null
          joined_at: string
          progress: number
          user_id: string
        }
        Insert: {
          challenge_id: string
          completed_at?: string | null
          joined_at?: string
          progress?: number
          user_id: string
        }
        Update: {
          challenge_id?: string
          completed_at?: string | null
          joined_at?: string
          progress?: number
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "challenge_participants_challenge_id_fkey"
            columns: ["challenge_id"]
            isOneToOne: false
            referencedRelation: "community_challenges"
            referencedColumns: ["id"]
          },
        ]
      }
      communities: {
        Row: {
          created_at: string
          created_by: string | null
          description: string
          emoji: string
          id: string
          member_count: number
          name: string
          slug: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          description?: string
          emoji?: string
          id?: string
          member_count?: number
          name: string
          slug: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          description?: string
          emoji?: string
          id?: string
          member_count?: number
          name?: string
          slug?: string
        }
        Relationships: []
      }
      community_challenges: {
        Row: {
          badge_code: string | null
          community_id: string
          created_at: string
          created_by: string | null
          description: string
          ends_on: string
          id: string
          required_quests: number
          starts_on: string
          title: string
          xp_reward: number
        }
        Insert: {
          badge_code?: string | null
          community_id: string
          created_at?: string
          created_by?: string | null
          description?: string
          ends_on?: string
          id?: string
          required_quests?: number
          starts_on?: string
          title: string
          xp_reward?: number
        }
        Update: {
          badge_code?: string | null
          community_id?: string
          created_at?: string
          created_by?: string | null
          description?: string
          ends_on?: string
          id?: string
          required_quests?: number
          starts_on?: string
          title?: string
          xp_reward?: number
        }
        Relationships: [
          {
            foreignKeyName: "community_challenges_badge_code_fkey"
            columns: ["badge_code"]
            isOneToOne: false
            referencedRelation: "achievements"
            referencedColumns: ["code"]
          },
          {
            foreignKeyName: "community_challenges_community_id_fkey"
            columns: ["community_id"]
            isOneToOne: false
            referencedRelation: "communities"
            referencedColumns: ["id"]
          },
        ]
      }
      community_members: {
        Row: {
          community_id: string
          joined_at: string
          role: string
          user_id: string
        }
        Insert: {
          community_id: string
          joined_at?: string
          role?: string
          user_id: string
        }
        Update: {
          community_id?: string
          joined_at?: string
          role?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "community_members_community_id_fkey"
            columns: ["community_id"]
            isOneToOne: false
            referencedRelation: "communities"
            referencedColumns: ["id"]
          },
        ]
      }
      community_posts: {
        Row: {
          body: string
          community_id: string
          created_at: string
          id: string
          kind: string
          meta: Json
          user_id: string
        }
        Insert: {
          body: string
          community_id: string
          created_at?: string
          id?: string
          kind?: string
          meta?: Json
          user_id: string
        }
        Update: {
          body?: string
          community_id?: string
          created_at?: string
          id?: string
          kind?: string
          meta?: Json
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "community_posts_community_id_fkey"
            columns: ["community_id"]
            isOneToOne: false
            referencedRelation: "communities"
            referencedColumns: ["id"]
          },
        ]
      }
      daily_activity: {
        Row: {
          day: string
          gold_earned: number
          quests_completed: number
          user_id: string
          xp_earned: number
        }
        Insert: {
          day: string
          gold_earned?: number
          quests_completed?: number
          user_id: string
          xp_earned?: number
        }
        Update: {
          day?: string
          gold_earned?: number
          quests_completed?: number
          user_id?: string
          xp_earned?: number
        }
        Relationships: []
      }
      goals: {
        Row: {
          completed_at: string | null
          completed_quests: number
          created_at: string
          emoji: string
          id: string
          target_quests: number
          title: string
          user_id: string
        }
        Insert: {
          completed_at?: string | null
          completed_quests?: number
          created_at?: string
          emoji?: string
          id?: string
          target_quests?: number
          title: string
          user_id: string
        }
        Update: {
          completed_at?: string | null
          completed_quests?: number
          created_at?: string
          emoji?: string
          id?: string
          target_quests?: number
          title?: string
          user_id?: string
        }
        Relationships: []
      }
      inventory: {
        Row: {
          item_code: string
          quantity: number
          user_id: string
        }
        Insert: {
          item_code: string
          quantity?: number
          user_id: string
        }
        Update: {
          item_code?: string
          quantity?: number
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "inventory_item_code_fkey"
            columns: ["item_code"]
            isOneToOne: false
            referencedRelation: "items"
            referencedColumns: ["code"]
          },
        ]
      }
      items: {
        Row: {
          code: string
          description: string
          effect: string
          emoji: string
          name: string
          price_gold: number
          rarity: string
          sort_order: number
        }
        Insert: {
          code: string
          description: string
          effect: string
          emoji: string
          name: string
          price_gold: number
          rarity?: string
          sort_order?: number
        }
        Update: {
          code?: string
          description?: string
          effect?: string
          emoji?: string
          name?: string
          price_gold?: number
          rarity?: string
          sort_order?: number
        }
        Relationships: []
      }
      player_effects: {
        Row: {
          streak_shields: number
          user_id: string
          xp_boost_quests_left: number
        }
        Insert: {
          streak_shields?: number
          user_id: string
          xp_boost_quests_left?: number
        }
        Update: {
          streak_shields?: number
          user_id?: string
          xp_boost_quests_left?: number
        }
        Relationships: []
      }
      post_reactions: {
        Row: {
          created_at: string
          emoji: string
          post_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          emoji: string
          post_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          emoji?: string
          post_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "post_reactions_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "community_posts"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_emoji: string
          created_at: string
          current_streak: number
          display_name: string
          gold: number
          id: string
          is_public: boolean
          last_active_date: string | null
          level: number
          longest_streak: number
          quests_completed: number
          timezone: string
          title: string
          xp: number
        }
        Insert: {
          avatar_emoji?: string
          created_at?: string
          current_streak?: number
          display_name?: string
          gold?: number
          id: string
          is_public?: boolean
          last_active_date?: string | null
          level?: number
          longest_streak?: number
          quests_completed?: number
          timezone?: string
          title?: string
          xp?: number
        }
        Update: {
          avatar_emoji?: string
          created_at?: string
          current_streak?: number
          display_name?: string
          gold?: number
          id?: string
          is_public?: boolean
          last_active_date?: string | null
          level?: number
          longest_streak?: number
          quests_completed?: number
          timezone?: string
          title?: string
          xp?: number
        }
        Relationships: []
      }
      quest_completions: {
        Row: {
          category: string
          completed_at: string
          day: string
          gold_awarded: number
          id: string
          quest_id: string
          user_id: string
          xp_awarded: number
        }
        Insert: {
          category?: string
          completed_at?: string
          day: string
          gold_awarded: number
          id?: string
          quest_id: string
          user_id: string
          xp_awarded: number
        }
        Update: {
          category?: string
          completed_at?: string
          day?: string
          gold_awarded?: number
          id?: string
          quest_id?: string
          user_id?: string
          xp_awarded?: number
        }
        Relationships: [
          {
            foreignKeyName: "quest_completions_quest_id_fkey"
            columns: ["quest_id"]
            isOneToOne: true
            referencedRelation: "quests"
            referencedColumns: ["id"]
          },
        ]
      }
      quests: {
        Row: {
          category: string
          completed_at: string | null
          created_at: string
          difficulty: Database["public"]["Enums"]["quest_difficulty"]
          goal_id: string | null
          gold_reward: number
          id: string
          quest_date: string
          recovered_from: string | null
          source: string
          status: Database["public"]["Enums"]["quest_status"]
          title: string
          user_id: string
          xp_reward: number
        }
        Insert: {
          category?: string
          completed_at?: string | null
          created_at?: string
          difficulty?: Database["public"]["Enums"]["quest_difficulty"]
          goal_id?: string | null
          gold_reward?: number
          id?: string
          quest_date: string
          recovered_from?: string | null
          source?: string
          status?: Database["public"]["Enums"]["quest_status"]
          title: string
          user_id: string
          xp_reward?: number
        }
        Update: {
          category?: string
          completed_at?: string | null
          created_at?: string
          difficulty?: Database["public"]["Enums"]["quest_difficulty"]
          goal_id?: string | null
          gold_reward?: number
          id?: string
          quest_date?: string
          recovered_from?: string | null
          source?: string
          status?: Database["public"]["Enums"]["quest_status"]
          title?: string
          user_id?: string
          xp_reward?: number
        }
        Relationships: [
          {
            foreignKeyName: "quests_goal_id_fkey"
            columns: ["goal_id"]
            isOneToOne: false
            referencedRelation: "goals"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "quests_recovered_from_fkey"
            columns: ["recovered_from"]
            isOneToOne: false
            referencedRelation: "quests"
            referencedColumns: ["id"]
          },
        ]
      }
      security_flags: {
        Row: {
          created_at: string
          details: Json
          id: string
          reason: string
          user_id: string
        }
        Insert: {
          created_at?: string
          details?: Json
          id?: string
          reason: string
          user_id: string
        }
        Update: {
          created_at?: string
          details?: Json
          id?: string
          reason?: string
          user_id?: string
        }
        Relationships: []
      }
      social_shares: {
        Row: {
          created_at: string
          id: string
          kind: string
          platform: string
          user_id: string
          verification: string
        }
        Insert: {
          created_at?: string
          id?: string
          kind: string
          platform?: string
          user_id: string
          verification?: string
        }
        Update: {
          created_at?: string
          id?: string
          kind?: string
          platform?: string
          user_id?: string
          verification?: string
        }
        Relationships: []
      }
      transactions: {
        Row: {
          created_at: string
          description: string
          gold_delta: number
          id: string
          kind: string
          user_id: string
          xp_delta: number
        }
        Insert: {
          created_at?: string
          description?: string
          gold_delta?: number
          id?: string
          kind: string
          user_id: string
          xp_delta?: number
        }
        Update: {
          created_at?: string
          description?: string
          gold_delta?: number
          id?: string
          kind?: string
          user_id?: string
          xp_delta?: number
        }
        Relationships: []
      }
      user_achievements: {
        Row: {
          code: string
          unlocked_at: string
          user_id: string
        }
        Insert: {
          code: string
          unlocked_at?: string
          user_id: string
        }
        Update: {
          code?: string
          unlocked_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_achievements_code_fkey"
            columns: ["code"]
            isOneToOne: false
            referencedRelation: "achievements"
            referencedColumns: ["code"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      check_achievements: { Args: { p_user: string }; Returns: Json }
      complete_quest: { Args: { p_quest_id: string }; Returns: Json }
      get_community_leaderboard: {
        Args: { p_community_id: string }
        Returns: {
          avatar_emoji: string
          display_name: string
          level: number
          score: number
          user_id: string
        }[]
      }
      get_leaderboard: {
        Args: { p_period?: string }
        Returns: {
          avatar_emoji: string
          display_name: string
          level: number
          score: number
          streak: number
          title: string
          user_id: string
        }[]
      }
      grant_rewards: {
        Args: {
          p_desc: string
          p_gold: number
          p_kind: string
          p_user: string
          p_xp: number
        }
        Returns: undefined
      }
      join_community: { Args: { p_community_id: string }; Returns: Json }
      leave_community: { Args: { p_community_id: string }; Returns: undefined }
      level_for_xp: { Args: { p_xp: number }; Returns: number }
      purchase_item: { Args: { p_item_code: string }; Returns: Json }
      record_social_share: {
        Args: { p_kind: string; p_platform: string }
        Returns: Json
      }
      title_for_level: { Args: { p_level: number }; Returns: string }
      use_item: { Args: { p_item_code: string }; Returns: Json }
      user_today: { Args: { p_user: string }; Returns: string }
      xp_for_level: { Args: { p_level: number }; Returns: number }
    }
    Enums: {
      quest_difficulty: "easy" | "medium" | "hard" | "epic"
      quest_status: "pending" | "completed" | "skipped"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      quest_difficulty: ["easy", "medium", "hard", "epic"],
      quest_status: ["pending", "completed", "skipped"],
    },
  },
} as const
