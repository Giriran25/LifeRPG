import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";

import { Reveal } from "@/components/game/Reveal";
import { Heatmap } from "@/components/game/Heatmap";
import { ShareCard } from "@/components/game/ShareCard";
import { Skeleton } from "@/components/ui/skeleton";
import { formatNumber } from "@/lib/game";
import { getDayDetail, getPlayerState, getProgress } from "@/lib/player.functions";

export const Route = createFileRoute("/_authenticated/progress")({
  head: () => ({
    meta: [
      { title: "Your Progress — Life RPG" },
      {
        name: "description",
        content:
          "A year of activity in one heatmap, your weekly summary, badge collection and productivity patterns.",
      },
      { property: "og:title", content: "Your Progress — Life RPG" },
      { property: "og:description", content: "Heatmap, weekly summary and badges." },
    ],
  }),
  component: Progress,
});

function Progress() {
  const [selected, setSelected] = useState<string | null>(null);

  const progress = useQuery({ queryKey: ["progress"], queryFn: () => getProgress() });
  const player = useQuery({ queryKey: ["player"], queryFn: () => getPlayerState() });
  const day = useQuery({
    queryKey: ["day", selected],
    queryFn: () => getDayDetail({ data: { day: selected as string } }),
    enabled: Boolean(selected),
  });

  if (progress.isLoading || !progress.data) return <Skeleton className="h-96 w-full rounded-2xl" />;

  const { week, activity, achievements, unlocked, monthCategories, today } = progress.data;
  const unlockedCodes = new Set(unlocked.map((u) => u.code));
  const profile = player.data?.profile;

  return (
    <div className="space-y-6">
      <h1 className="display text-2xl">Your Progress</h1>

      <Reveal as="section" className="panel p-5">
        <h2 className="text-lg">Activity heatmap</h2>
        <p className="text-muted-foreground mt-1 text-sm">
          Each square is a day. Intensity is the XP you earned. Click a day for details.
        </p>
        <div className="mt-4">
          <Heatmap activity={activity} today={today} onSelect={setSelected} selected={selected} />
        </div>

        {selected ? (
          <div className="bg-secondary/40 mt-4 rounded-xl p-4">
            <p className="text-sm font-medium">{selected}</p>
            {day.isLoading ? (
              <Skeleton className="mt-2 h-16 w-full" />
            ) : day.data && day.data.quests.length ? (
              <>
                <p className="text-muted-foreground mt-1 text-xs">
                  {day.data.activity?.quests_completed ?? day.data.quests.length} quests ·{" "}
                  {formatNumber(day.data.activity?.xp_earned ?? 0)} XP · 💰{" "}
                  {formatNumber(day.data.activity?.gold_earned ?? 0)}
                </p>
                <ul className="mt-2 space-y-1 text-sm">
                  {day.data.quests.map((q) => (
                    <li key={q.quest_id} className="flex justify-between gap-2">
                      <span className="truncate">{q.title}</span>
                      <span className="text-primary shrink-0">+{q.xp_awarded} XP</span>
                    </li>
                  ))}
                </ul>
              </>
            ) : (
              <p className="text-muted-foreground mt-1 text-sm">No quests completed this day.</p>
            )}
          </div>
        ) : null}
      </Reveal>

      <div className="grid gap-6 lg:grid-cols-2">
        <Reveal as="section" className="panel p-5">
          <h2 className="text-lg">Your week</h2>
          <dl className="mt-4 grid grid-cols-2 gap-4 text-sm">
            <div>
              <dt className="text-muted-foreground text-xs uppercase">Quests</dt>
              <dd className="display text-xl">{week.quests}</dd>
            </div>
            <div>
              <dt className="text-muted-foreground text-xs uppercase">XP</dt>
              <dd className="display text-primary text-xl">{formatNumber(week.xp)}</dd>
            </div>
            <div>
              <dt className="text-muted-foreground text-xs uppercase">Best day</dt>
              <dd className="text-base">
                {week.bestDay ? `${week.bestDay} (${week.bestDayCount})` : "—"}
              </dd>
            </div>
            <div>
              <dt className="text-muted-foreground text-xs uppercase">Top category</dt>
              <dd className="text-base">{week.topCategory ?? "—"}</dd>
            </div>
          </dl>
          {week.changePercent !== null ? (
            <p className="text-muted-foreground mt-4 text-sm">
              XP compared to the previous week:{" "}
              <span className={week.changePercent >= 0 ? "text-chart-5" : "text-ember"}>
                {week.changePercent >= 0 ? "+" : ""}
                {week.changePercent}%
              </span>
            </p>
          ) : (
            <p className="text-muted-foreground mt-4 text-sm">
              Not enough history yet to compare weeks.
            </p>
          )}
          {week.peakHour !== null && week.quests >= 3 ? (
            <p className="mt-2 text-sm">
              Most of your quests land around {week.peakHour}:00 — plan your hardest one there.
            </p>
          ) : null}
        </Reveal>

        <Reveal as="section" className="panel p-5">
          <h2 className="text-lg">Last 30 days by category</h2>
          {monthCategories.length === 0 ? (
            <p className="text-muted-foreground mt-3 text-sm">No completions in the last 30 days.</p>
          ) : (
            <ul className="mt-4 space-y-3">
              {monthCategories
                .sort((a, b) => b.count - a.count)
                .map((c) => {
                  const max = Math.max(...monthCategories.map((x) => x.count));
                  return (
                    <li key={c.category}>
                      <div className="flex justify-between text-sm">
                        <span>{c.category}</span>
                        <span className="text-muted-foreground">{c.count}</span>
                      </div>
                      <div className="bg-secondary/70 mt-1 h-2 overflow-hidden rounded-full">
                        <div
                          className="bg-arcane h-full rounded-full"
                          style={{ width: `${(c.count / max) * 100}%` }}
                        />
                      </div>
                    </li>
                  );
                })}
            </ul>
          )}
        </Reveal>
      </div>

      <Reveal as="section" className="panel p-5">
        <h2 className="text-lg">Badge collection</h2>
        <p className="text-muted-foreground mt-1 text-sm">
          {unlockedCodes.size} of {achievements.length} unlocked.
        </p>
        <ul className="mt-4 grid grid-cols-3 gap-3 sm:grid-cols-4 lg:grid-cols-6">
          {achievements.map((a) => {
            const has = unlockedCodes.has(a.code);
            return (
              <li
                key={a.code}
                className={`panel p-3 text-center ${has ? "glow-gold" : "opacity-45 grayscale"}`}
                title={a.description}
              >
                <div className="text-2xl">{has ? a.emoji : "🔒"}</div>
                <p className="mt-1 text-xs font-medium">{a.name}</p>
                <p className="text-muted-foreground mt-0.5 text-[10px]">{a.description}</p>
              </li>
            );
          })}
        </ul>
      </Reveal>

      {profile ? (
        <Reveal as="section" className="panel p-5">
          <h2 className="text-lg">Share your week</h2>
          <div className="mt-4 max-w-md">
            <ShareCard
              kind="weekly_summary"
              headline={`${week.quests} quests, ${formatNumber(week.xp)} XP this week`}
              quote={week.topCategory ? `Strongest at ${week.topCategory}.` : "Still going."}
              stats={{
                level: profile.level,
                xp: profile.xp,
                streak: profile.current_streak,
              }}
            />
          </div>
        </Reveal>
      ) : null}
    </div>
  );
}
