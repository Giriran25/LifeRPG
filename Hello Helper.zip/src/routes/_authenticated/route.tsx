import { createFileRoute, Link, Outlet, redirect, useRouter } from "@tanstack/react-router";
import { useEffect } from "react";
import { BarChart3, Globe2, Home, LogOut, Swords, User, Users } from "lucide-react";

import { supabase } from "@/integrations/supabase/client";
import { CelebrationProvider } from "@/components/game/Celebration";
import { CoachChat } from "@/components/game/CoachChat";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async () => {
    const { data, error } = await supabase.auth.getUser();
    if (error || !data.user) throw redirect({ to: "/auth" });
    return { user: data.user };
  },
  component: AuthedLayout,
});

const NAV = [
  { to: "/adventure", label: "Adventure", icon: Home },
  { to: "/quests", label: "Quests", icon: Swords },
  { to: "/progress", label: "Progress", icon: BarChart3 },
  { to: "/leaderboard", label: "Ranking", icon: Globe2 },
  { to: "/community", label: "Community", icon: Users },
  { to: "/character", label: "Character", icon: User },
] as const;

function AuthedLayout() {
  const router = useRouter();

  useEffect(() => {
    const { data } = supabase.auth.onAuthStateChange((event) => {
      if (event === "SIGNED_OUT" || event === "SIGNED_IN") void router.invalidate();
    });
    return () => data.subscription.unsubscribe();
  }, [router]);

  return (
    <CelebrationProvider>
      <div className="min-h-screen pb-24 lg:pb-0">
        <header className="border-border/60 bg-background/70 sticky top-0 z-30 border-b backdrop-blur-xl">
          <div className="mx-auto flex max-w-6xl items-center gap-4 px-4 py-3">
            <Link to="/adventure" className="display text-primary text-sm tracking-[0.3em] uppercase">
              Life RPG
            </Link>
            <nav aria-label="Main" className="hidden flex-1 items-center gap-1 lg:flex">
              {NAV.map((item) => (
                <Link
                  key={item.to}
                  to={item.to}
                  className="text-muted-foreground hover:text-foreground rounded-lg px-3 py-2 text-sm transition-colors"
                  activeProps={{ className: "text-primary bg-secondary/60" }}
                >
                  {item.label}
                </Link>
              ))}
            </nav>
            <Button
              variant="ghost"
              size="sm"
              className="ml-auto gap-2"
              onClick={async () => {
                await supabase.auth.signOut();
                window.location.href = "/";
              }}
            >
              <LogOut className="size-4" aria-hidden />
              <span className="sr-only sm:not-sr-only">Sign out</span>
            </Button>
          </div>
        </header>

        <main className="mx-auto max-w-6xl px-4 py-6">
          <Outlet />
        </main>

        <CoachChat />

        <nav
          aria-label="Main mobile"
          className="border-border/60 bg-background/90 fixed inset-x-0 bottom-0 z-30 border-t backdrop-blur-xl lg:hidden"
        >
          <ul className="flex justify-between px-1 py-2">
            {NAV.map((item) => (
              <li key={item.to} className="flex-1">
                <Link
                  to={item.to}
                  className={cn(
                    "text-muted-foreground flex flex-col items-center gap-1 rounded-lg px-1 py-1 text-[10px]",
                  )}
                  activeProps={{ className: "text-primary" }}
                >
                  <item.icon className="size-5" aria-hidden />
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </CelebrationProvider>
  );
}
