import { createFileRoute, Link, useParams } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { ArrowLeft, Send } from "lucide-react";
import { toast } from "sonner";

import { Reveal } from "@/components/game/Reveal";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import {
  createPost,
  getCommunityDetail,
  joinChallenge,
  joinCommunity,
  leaveCommunity,
  toggleReaction,
} from "@/lib/social.functions";

export const Route = createFileRoute("/_authenticated/community/$communityId")({
  head: () => ({
    meta: [
      { title: "Guild hall — Life RPG" },
      {
        name: "description",
        content: "Post updates, react to guild mates and join guild challenges in Life RPG.",
      },
      { property: "og:title", content: "Guild hall — Life RPG" },
      { property: "og:description", content: "Your guild feed, challenges and rankings." },
    ],
  }),
  component: CommunityDetail,
});

const EMOJIS = ["🔥", "💪", "👏", "🧠"] as const;

function CommunityDetail() {
  const { communityId } = useParams({ from: "/_authenticated/community/$communityId" });
  const qc = useQueryClient();
  const [body, setBody] = useState("");

  const detail = useQuery({
    queryKey: ["community", communityId],
    queryFn: () => getCommunityDetail({ data: { id: communityId } }),
  });
  const invalidate = () => void qc.invalidateQueries({ queryKey: ["community", communityId] });

  const post = useMutation({
    mutationFn: () => createPost({ data: { communityId, body: body.trim() } }),
    onSuccess: () => {
      setBody("");
      invalidate();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const react = useMutation({
    mutationFn: (input: { postId: string; emoji: string }) => toggleReaction({ data: input }),
    onSuccess: invalidate,
    onError: (e: Error) => toast.error(e.message),
  });

  const membership = useMutation({
    mutationFn: (join: boolean) =>
      join ? joinCommunity({ data: { id: communityId } }) : leaveCommunity({ data: { id: communityId } }),
    onSuccess: invalidate,
    onError: (e: Error) => toast.error(e.message),
  });

  const challenge = useMutation({
    mutationFn: (id: string) => joinChallenge({ data: { id } }),
    onSuccess: () => {
      toast.success("Challenge accepted.");
      invalidate();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (detail.isLoading || !detail.data) return <Skeleton className="h-96 w-full rounded-2xl" />;
  const d = detail.data;
  if (!d.community) {
    return (
      <div className="panel p-6">
        <p>This guild no longer exists.</p>
        <Button asChild variant="secondary" size="sm" className="mt-3">
          <Link to="/community">Back to guilds</Link>
        </Button>
      </div>
    );
  }

  const authors = new Map(d.authors.map((a) => [a.id, a]));
  const joinedChallenges = new Set(d.myParticipation.map((p) => p.challenge_id));

  return (
    <div className="space-y-6">
      <div className="flex items-start gap-3">
        <Button asChild variant="ghost" size="icon">
          <Link to="/community" aria-label="Back to guilds">
            <ArrowLeft className="size-4" aria-hidden />
          </Link>
        </Button>
        <div className="min-w-0 flex-1">
          <h1 className="display text-2xl">
            {d.community.emoji} {d.community.name}
          </h1>
          <p className="text-muted-foreground mt-1 text-sm">{d.community.description}</p>
        </div>
        <Button
          size="sm"
          variant={d.isMember ? "ghost" : "default"}
          disabled={membership.isPending}
          onClick={() => membership.mutate(!d.isMember)}
        >
          {d.isMember ? "Leave" : "Join"}
        </Button>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.6fr_1fr]">
        <div className="space-y-4">
          {d.isMember ? (
            <section className="panel p-4">
              <Textarea
                value={body}
                onChange={(e) => setBody(e.target.value)}
                placeholder="Share a win, a tip or a question with your guild…"
                rows={3}
              />
              <div className="mt-2 flex justify-end">
                <Button
                  size="sm"
                  className="gap-2"
                  disabled={body.trim().length < 2 || post.isPending}
                  onClick={() => post.mutate()}
                >
                  <Send className="size-4" aria-hidden /> Post
                </Button>
              </div>
            </section>
          ) : (
            <p className="panel text-muted-foreground p-4 text-sm">
              Join this guild to post and react.
            </p>
          )}

          {d.posts.length === 0 ? (
            <p className="panel text-muted-foreground p-5 text-sm">
              No posts yet. Be the first to share progress.
            </p>
          ) : (
            <ul className="space-y-3">
              {d.posts.map((p, i) => {
                const author = authors.get(p.user_id);
                const counts = new Map<string, number>();
                const mine = new Set<string>();
                for (const r of d.reactions.filter((r) => r.post_id === p.id)) {
                  counts.set(r.emoji, (counts.get(r.emoji) ?? 0) + 1);
                  if (r.user_id === d.me) mine.add(r.emoji);
                }
                return (
                  <Reveal as="li" key={p.id} delay={i * 60} className="panel p-4">
                    <div className="flex items-center gap-2">
                      <span className="text-xl">{author?.avatar_emoji ?? "🧙"}</span>
                      <div className="min-w-0">
                        <p className="text-sm font-medium">{author?.display_name ?? "Adventurer"}</p>
                        <p className="text-muted-foreground text-xs">
                          Level {author?.level ?? 1} · {new Date(p.created_at).toLocaleString()}
                        </p>
                      </div>
                    </div>
                    <p className="mt-3 text-sm whitespace-pre-wrap">{p.body}</p>
                    <div className="mt-3 flex flex-wrap gap-1">
                      {EMOJIS.map((emoji) => (
                        <Button
                          key={emoji}
                          size="sm"
                          variant={mine.has(emoji) ? "secondary" : "ghost"}
                          disabled={!d.isMember}
                          onClick={() => react.mutate({ postId: p.id, emoji })}
                        >
                          {emoji} {counts.get(emoji) ?? 0}
                        </Button>
                      ))}
                    </div>
                  </Reveal>
                );
              })}
            </ul>
          )}
        </div>

        <div className="space-y-4">
          <Reveal as="section" className="panel p-5">
            <h2 className="text-lg">Challenges</h2>
            {d.challenges.length === 0 ? (
              <p className="text-muted-foreground mt-2 text-sm">No active challenges.</p>
            ) : (
              <ul className="mt-3 space-y-3">
                {d.challenges.map((c) => (
                  <li key={c.id} className="border-border/60 rounded-xl border p-3">
                    <p className="text-sm font-medium">{c.title}</p>
                    <p className="text-muted-foreground mt-1 text-xs">{c.description}</p>
                    <p className="text-muted-foreground mt-1 text-xs">
                      {c.required_quests} quests · ends {c.ends_on}
                    </p>
                    <Button
                      size="sm"
                      className="mt-2"
                      variant={joinedChallenges.has(c.id) ? "secondary" : "default"}
                      disabled={joinedChallenges.has(c.id) || !d.isMember}
                      onClick={() => challenge.mutate(c.id)}
                    >
                      {joinedChallenges.has(c.id) ? "Joined" : "Accept"}
                    </Button>
                  </li>
                ))}
              </ul>
            )}
          </Reveal>

          <Reveal as="section" className="panel p-5">
            <h2 className="text-lg">Guild ranking</h2>
            {d.leaderboard.length === 0 ? (
              <p className="text-muted-foreground mt-2 text-sm">No scores yet this week.</p>
            ) : (
              <ol className="mt-3 space-y-2">
                {d.leaderboard.map((row, i) => (
                  <li key={row.user_id} className="flex items-center gap-2 text-sm">
                    <span className="text-muted-foreground w-5 text-xs">{i + 1}</span>
                    <span>{row.avatar_emoji}</span>
                    <span className="min-w-0 flex-1 truncate">{row.display_name}</span>
                    <span className="text-primary">{row.score}</span>
                  </li>
                ))}
              </ol>
            )}
          </Reveal>
        </div>
      </div>
    </div>
  );
}
