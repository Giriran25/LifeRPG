import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";

import { Reveal } from "@/components/game/Reveal";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { getCommunities, joinCommunity, leaveCommunity } from "@/lib/social.functions";

export const Route = createFileRoute("/_authenticated/community/")({
  head: () => ({
    meta: [
      { title: "Guilds & Community — Life RPG" },
      {
        name: "description",
        content: "Join guilds of people chasing the same goals and keep each other consistent.",
      },
      { property: "og:title", content: "Guilds & Community — Life RPG" },
      { property: "og:description", content: "Find your guild and stay accountable." },
    ],
  }),
  component: Community,
});

function Community() {
  const qc = useQueryClient();
  const data = useQuery({ queryKey: ["communities"], queryFn: () => getCommunities() });
  const invalidate = () => void qc.invalidateQueries({ queryKey: ["communities"] });

  const join = useMutation({
    mutationFn: (id: string) => joinCommunity({ data: { id } }),
    onSuccess: () => {
      toast.success("Welcome to the guild.");
      invalidate();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const leave = useMutation({
    mutationFn: (id: string) => leaveCommunity({ data: { id } }),
    onSuccess: invalidate,
    onError: (e: Error) => toast.error(e.message),
  });

  if (data.isLoading || !data.data) return <Skeleton className="h-96 w-full rounded-2xl" />;

  const memberIds = new Set(data.data.memberships.map((m) => m.community_id));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="display text-2xl">🏰 Guilds</h1>
        <p className="text-muted-foreground mt-1 text-sm">
          Communities of adventurers working on the same kind of progress.
        </p>
      </div>

      {data.data.suggested.length ? (
        <section className="panel p-5">
          <h2 className="text-lg">Recommended for you</h2>
          <p className="text-muted-foreground mt-1 text-sm">
            Based on the categories you actually complete quests in.
          </p>
          <ul className="mt-3 flex flex-wrap gap-2">
            {data.data.suggested.map((c) => (
              <li key={c.id} className="bg-secondary/50 rounded-full px-3 py-1 text-sm">
                {c.emoji} {c.name}
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      <ul className="grid gap-4 md:grid-cols-2">
        {data.data.communities.map((c, i) => {
          const joined = memberIds.has(c.id);
          return (
            <Reveal
              as="li"
              key={c.id}
              delay={i * 70}
              className="panel hover-scale flex flex-col gap-3 p-5"
            >
              <div className="flex items-start gap-3">
                <span className="text-2xl">{c.emoji}</span>
                <div className="min-w-0">
                  <p className="font-medium">{c.name}</p>
                  <p className="text-muted-foreground mt-1 text-sm">{c.description}</p>
                </div>
              </div>
              <div className="mt-auto flex items-center justify-between gap-2">
                <span className="text-muted-foreground text-xs">
                  {c.member_count} member{c.member_count === 1 ? "" : "s"}
                </span>
                <div className="flex items-center gap-1">
                  <Button asChild variant="secondary" size="sm">
                    <Link to="/community/$communityId" params={{ communityId: c.id }}>
                      Open
                    </Link>
                  </Button>
                  {joined ? (
                    <Button variant="ghost" size="sm" onClick={() => leave.mutate(c.id)}>
                      Leave
                    </Button>
                  ) : (
                    <Button size="sm" onClick={() => join.mutate(c.id)}>
                      Join
                    </Button>
                  )}
                </div>
              </div>
            </Reveal>
          );
        })}
      </ul>
    </div>
  );
}
