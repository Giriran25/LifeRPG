import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { toast } from "sonner";

import { AddQuestDialog, type NewQuest } from "@/components/game/AddQuestDialog";
import { useCelebration } from "@/components/game/Celebration";
import { QuestCard, type Quest } from "@/components/game/QuestCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  completeQuest,
  createGoal,
  createQuests,
  deleteQuest,
  getPlayerState,
} from "@/lib/player.functions";

export const Route = createFileRoute("/_authenticated/quests")({
  head: () => ({
    meta: [
      { title: "Quest Log — Life RPG" },
      {
        name: "description",
        content: "Every quest you've taken on, plus the long-term goals they feed into.",
      },
      { property: "og:title", content: "Quest Log — Life RPG" },
      { property: "og:description", content: "Manage your quests and goals." },
    ],
  }),
  component: QuestLog,
});

function QuestLog() {
  const qc = useQueryClient();
  const { celebrate } = useCelebration();
  const [filter, setFilter] = useState<"today" | "pending" | "completed">("today");
  const [goalTitle, setGoalTitle] = useState("");
  const [goalTarget, setGoalTarget] = useState("20");
  const [busyId, setBusyId] = useState<string | null>(null);

  const state = useQuery({ queryKey: ["player"], queryFn: () => getPlayerState() });
  const invalidate = () => void qc.invalidateQueries({ queryKey: ["player"] });

  const add = useMutation({
    mutationFn: (q: NewQuest) =>
      createQuests({
        data: [q].map((x) => ({
          title: x.title,
          category: x.category,
          difficulty: x.difficulty,
          goal_id: x.goal_id ?? null,
          source: "manual",
        })) as never,
      }),
    onSuccess: invalidate,
    onError: (e: Error) => toast.error(e.message),
  });

  const complete = useMutation({
    mutationFn: (quest: Quest) => completeQuest({ data: { questId: quest.id } }),
    onMutate: (q) => setBusyId(q.id),
    onSettled: () => setBusyId(null),
    onSuccess: (result, quest) => {
      toast.success(`${quest.title} · +${result.xp_awarded} XP`);
      if (result.leveled_up) {
        celebrate({
          kind: "level",
          title: `Level ${result.new_level} reached`,
          fromLevel: result.previous_level,
          toLevel: result.new_level,
          stats: {
            level: result.profile.level,
            xp: result.profile.xp,
            streak: result.profile.current_streak,
          },
        });
      }
      for (const badge of result.unlocked ?? []) {
        celebrate({ kind: "badge", title: badge.name, subtitle: badge.description, badges: [badge] });
      }
      invalidate();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const remove = useMutation({
    mutationFn: (quest: Quest) => deleteQuest({ data: { questId: quest.id } }),
    onSuccess: invalidate,
  });

  const addGoal = useMutation({
    mutationFn: () =>
      createGoal({
        data: { title: goalTitle.trim(), target_quests: Number(goalTarget) || 20, emoji: "🎯" },
      }),
    onSuccess: () => {
      setGoalTitle("");
      toast.success("Goal added. Link quests to it as you go.");
      invalidate();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const quests = useMemo(() => {
    const all = state.data?.todayQuests ?? [];
    const recent = state.data ? [...all, ...state.data.recoveryQuests] : [];
    if (filter === "today") return all;
    if (filter === "pending") return recent.filter((q) => q.status === "pending");
    return recent.filter((q) => q.status === "completed");
  }, [state.data, filter]);

  if (state.isLoading || !state.data) return <Skeleton className="h-96 w-full rounded-2xl" />;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="display text-2xl">Quest Log</h1>
        <AddQuestDialog goals={state.data.goals} onCreate={(q) => add.mutate(q)} />
      </div>

      <Tabs value={filter} onValueChange={(v) => setFilter(v as typeof filter)}>
        <TabsList>
          <TabsTrigger value="today">Today</TabsTrigger>
          <TabsTrigger value="pending">Open</TabsTrigger>
          <TabsTrigger value="completed">Completed</TabsTrigger>
        </TabsList>
      </Tabs>

      {quests.length === 0 ? (
        <div className="panel p-10 text-center">
          <p className="display text-lg">Nothing here yet.</p>
          <p className="text-muted-foreground mt-2 text-sm">Forge a quest and the log fills up.</p>
        </div>
      ) : (
        <ul className="space-y-3">
          {quests.map((q) => (
            <QuestCard
              key={q.id}
              quest={q}
              busy={busyId === q.id}
              {...(q.status === "pending"
                ? {
                    onComplete: (quest: Quest) => complete.mutate(quest),
                    onDelete: (quest: Quest) => remove.mutate(quest),
                  }
                : {})}
            />
          ))}
        </ul>
      )}

      <section className="panel p-5">
        <h2 className="text-lg">🎯 Long-term goals</h2>
        <p className="text-muted-foreground mt-1 text-sm">
          Goals collect quests and track completion so the AI guide knows what you're aiming at.
        </p>

        <ul className="mt-4 space-y-3">
          {state.data.goals.map((g) => {
            const percent = Math.min(
              100,
              Math.round((g.completed_quests / Math.max(1, g.target_quests)) * 100),
            );
            return (
              <li key={g.id}>
                <div className="flex justify-between text-sm">
                  <span>
                    {g.emoji} {g.title}
                  </span>
                  <span className="text-muted-foreground">
                    {g.completed_quests}/{g.target_quests} · {percent}%
                  </span>
                </div>
                <div className="bg-secondary/70 mt-1 h-2 overflow-hidden rounded-full">
                  <div className="bg-accent h-full rounded-full" style={{ width: `${percent}%` }} />
                </div>
              </li>
            );
          })}
        </ul>

        <div className="mt-5 flex flex-wrap items-end gap-3">
          <div className="min-w-48 flex-1 space-y-2">
            <Label htmlFor="goal-title">New goal</Label>
            <Input
              id="goal-title"
              value={goalTitle}
              placeholder="Become a full stack developer"
              onChange={(e) => setGoalTitle(e.target.value)}
            />
          </div>
          <div className="w-28 space-y-2">
            <Label htmlFor="goal-target">Quests</Label>
            <Input
              id="goal-target"
              type="number"
              min={1}
              value={goalTarget}
              onChange={(e) => setGoalTarget(e.target.value)}
            />
          </div>
          <Button disabled={goalTitle.trim().length < 2} onClick={() => addGoal.mutate()}>
            Add goal
          </Button>
        </div>
      </section>
    </div>
  );
}
