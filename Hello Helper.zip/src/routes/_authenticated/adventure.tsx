import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Brain, Plus, RefreshCw, Sparkles, TriangleAlert } from "lucide-react";
import { toast } from "sonner";

import { AddQuestDialog, type NewQuest } from "@/components/game/AddQuestDialog";
import { useCelebration } from "@/components/game/Celebration";
import { PlayerHeader } from "@/components/game/PlayerHeader";
import { QuestCard, type Quest } from "@/components/game/QuestCard";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Skeleton } from "@/components/ui/skeleton";
import { getAiGuide, type AiSuggestion } from "@/lib/ai.functions";
import {
  completeQuest,
  createQuests,
  deleteQuest,
  dismissQuests,
  getPlayerState,
} from "@/lib/player.functions";
import { categoryEmoji } from "@/lib/game";

export const Route = createFileRoute("/_authenticated/adventure")({
  head: () => ({
    meta: [
      { title: "Today's Adventure — Life RPG" },
      {
        name: "description",
        content:
          "Your character, today's quests, recovered quests and AI coaching in one place.",
      },
      { property: "og:title", content: "Today's Adventure — Life RPG" },
      { property: "og:description", content: "Your quests, streak and AI guide for today." },
    ],
  }),
  component: Adventure,
});

function Adventure() {
  const qc = useQueryClient();
  const { celebrate } = useCelebration();
  const [busyId, setBusyId] = useState<string | null>(null);
  const [selectedRecovery, setSelectedRecovery] = useState<string[]>([]);

  const state = useQuery({ queryKey: ["player"], queryFn: () => getPlayerState() });
  const guide = useQuery({
    queryKey: ["ai-guide"],
    queryFn: () => getAiGuide({ data: { refresh: false } }),
    staleTime: 1000 * 60 * 30,
  });

  const invalidate = () => {
    void qc.invalidateQueries({ queryKey: ["player"] });
    void qc.invalidateQueries({ queryKey: ["progress"] });
  };

  const addQuests = useMutation({
    mutationFn: (quests: Array<NewQuest & { source?: string; recovered_from?: string | null }>) =>
      createQuests({
        data: {
          quests: quests.map((q) => ({
            title: q.title,
            category: q.category,
            difficulty: q.difficulty,
            goal_id: q.goal_id ?? null,
            source: q.source ?? "manual",
            recovered_from: q.recovered_from ?? null,
          })),
        },
      }),
    onSuccess: (res) => {
      toast.success(`${res.quests.length} quest${res.quests.length > 1 ? "s" : ""} added to today.`);
      setSelectedRecovery([]);
      invalidate();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const complete = useMutation({
    mutationFn: (quest: Quest) => completeQuest({ data: { questId: quest.id } }),
    onMutate: (quest) => setBusyId(quest.id),
    onSettled: () => setBusyId(null),
    onSuccess: (result, quest) => {
      toast.success(`${quest.title} complete · +${result.xp_awarded} XP · 💰 ${result.gold_awarded}`);
      const profile = result.profile;
      if (result.leveled_up) {
        celebrate({
          kind: "level",
          title: `Level ${result.new_level} reached`,
          subtitle: `New title unlocked: “${profile.title}”`,
          fromLevel: result.previous_level,
          toLevel: result.new_level,
          shareText: `${result.new_level} levels of showing up.`,
          stats: { level: profile.level, xp: profile.xp, streak: profile.current_streak },
        });
      }
      for (const badge of result.unlocked ?? []) {
        celebrate({
          kind: "badge",
          title: badge.name,
          subtitle: badge.description,
          badges: [badge],
          stats: { level: profile.level, xp: profile.xp, streak: profile.current_streak },
          shareText: badge.description,
        });
      }
      invalidate();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const removeQuest = useMutation({
    mutationFn: (quest: Quest) => deleteQuest({ data: { questId: quest.id } }),
    onSuccess: invalidate,
    onError: (e: Error) => toast.error(e.message),
  });

  const dismiss = useMutation({
    mutationFn: (ids: string[]) => dismissQuests({ data: { questIds: ids } }),
    onSuccess: () => {
      toast.info("Left behind. No penalty — today is a fresh start.");
      setSelectedRecovery([]);
      invalidate();
    },
  });

  if (state.isLoading || !state.data?.profile) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-40 w-full rounded-2xl" />
        <Skeleton className="h-24 w-full rounded-2xl" />
        <Skeleton className="h-64 w-full rounded-2xl" />
      </div>
    );
  }

  const { profile, todayQuests, recoveryQuests, usualQuests, goals } = state.data;
  const pending = todayQuests.filter((q) => q.status === "pending");
  const done = todayQuests.filter((q) => q.status === "completed");

  function addSuggestion(s: AiSuggestion) {
    addQuests.mutate([
      { title: s.title, category: s.category, difficulty: s.difficulty, source: "ai" },
    ]);
  }

  return (
    <div className="space-y-6">
      <PlayerHeader profile={profile} />

      {recoveryQuests.length ? (
        <section className="panel border-ember/40 p-5">
          <h2 className="text-ember flex items-center gap-2 text-lg">
            <TriangleAlert className="size-5" aria-hidden /> You left some quests behind
          </h2>
          <p className="text-muted-foreground mt-1 text-sm">
            {recoveryQuests.length} unfinished quest{recoveryQuests.length > 1 ? "s" : ""} from
            earlier days. Bring back the ones that still matter.
          </p>
          <ul className="mt-4 space-y-2">
            {recoveryQuests.map((q) => (
              <li key={q.id} className="bg-secondary/40 flex items-center gap-3 rounded-xl p-3">
                <Checkbox
                  id={`rec-${q.id}`}
                  checked={selectedRecovery.includes(q.id)}
                  onCheckedChange={(checked) =>
                    setSelectedRecovery((prev) =>
                      checked ? [...prev, q.id] : prev.filter((id) => id !== q.id),
                    )
                  }
                />
                <label htmlFor={`rec-${q.id}`} className="flex-1 cursor-pointer text-sm">
                  <span className="mr-2">{categoryEmoji(q.category)}</span>
                  {q.title}
                  <span className="text-muted-foreground ml-2 text-xs">{q.quest_date}</span>
                </label>
                <span className="text-primary text-xs">+{q.xp_reward} XP</span>
              </li>
            ))}
          </ul>
          <div className="mt-4 flex flex-wrap gap-2">
            <Button
              onClick={() => {
                const chosen = recoveryQuests.filter((q) =>
                  selectedRecovery.length ? selectedRecovery.includes(q.id) : true,
                );
                addQuests.mutate(
                  chosen.map((q) => ({
                    title: q.title,
                    category: q.category,
                    difficulty: q.difficulty as NewQuest["difficulty"],
                    source: "recovered",
                    recovered_from: q.id,
                  })),
                );
              }}
            >
              Add {selectedRecovery.length ? `${selectedRecovery.length} ` : "all "}to today
            </Button>
            <Button
              variant="ghost"
              onClick={() =>
                dismiss.mutate(
                  (selectedRecovery.length
                    ? selectedRecovery
                    : recoveryQuests.map((q) => q.id)) as string[],
                )
              }
            >
              Dismiss
            </Button>
          </div>
        </section>
      ) : null}

      <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
        <section className="panel p-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="display text-xl">Today's Adventure</h2>
              <p className="text-muted-foreground text-sm">
                {profile.current_streak > 0
                  ? `🔥 Keep your ${profile.current_streak}-day streak alive.`
                  : "Complete one quest to start a streak."}
              </p>
            </div>
            <AddQuestDialog
              goals={goals}
              onCreate={(q) => addQuests.mutate([q])}
              trigger={
                <Button className="gap-2">
                  <Plus className="size-4" aria-hidden /> New quest
                </Button>
              }
            />
          </div>

          {pending.length === 0 && done.length === 0 ? (
            <div className="border-border/60 mt-6 rounded-xl border border-dashed p-8 text-center">
              <p className="display text-lg">Your adventure begins here.</p>
              <p className="text-muted-foreground mt-2 text-sm">
                Add your first quest, or take one of the AI guide's suggestions.
              </p>
            </div>
          ) : (
            <ul className="mt-5 space-y-3">
              {pending.map((q) => (
                <QuestCard
                  key={q.id}
                  quest={q}
                  busy={busyId === q.id}
                  onComplete={(quest) => complete.mutate(quest)}
                  onDelete={(quest) => removeQuest.mutate(quest)}
                />
              ))}
              {done.map((q) => (
                <QuestCard key={q.id} quest={q} />
              ))}
            </ul>
          )}

          {done.length ? (
            <p className="text-muted-foreground mt-4 text-sm">
              {done.length} of {todayQuests.length} quests complete today.
            </p>
          ) : null}
        </section>

        <div className="space-y-6">
          <section className="panel p-5">
            <div className="flex items-center justify-between gap-2">
              <h2 className="flex items-center gap-2 text-lg">
                <Brain className="text-arcane size-5" aria-hidden /> AI Guide
              </h2>
              <Button
                size="icon"
                variant="ghost"
                aria-label="Regenerate AI guide"
                onClick={async () => {
                  const fresh = await getAiGuide({ data: { refresh: true } });
                  qc.setQueryData(["ai-guide"], fresh);
                }}
              >
                <RefreshCw className="size-4" aria-hidden />
              </Button>
            </div>

            {guide.isLoading ? (
              <Skeleton className="mt-4 h-32 w-full rounded-xl" />
            ) : guide.data ? (
              <div className="mt-3 space-y-4">
                <p className="text-sm leading-relaxed">🧠 {guide.data.motivation}</p>
                <p className="text-muted-foreground text-sm">{guide.data.insight}</p>

                {guide.data.suggestions.length ? (
                  <div>
                    <p className="text-muted-foreground text-xs tracking-widest uppercase">
                      Today's best moves
                    </p>
                    <ul className="mt-2 space-y-2">
                      {guide.data.suggestions.map((s, i) => (
                        <li key={`${s.title}-${i}`} className="bg-secondary/40 rounded-xl p-3">
                          <div className="flex items-start justify-between gap-2">
                            <div>
                              <p className="text-sm font-medium">
                                {i === 0 ? "⭐ " : ""}
                                {s.title}
                              </p>
                              <p className="text-muted-foreground mt-1 text-xs">{s.reason}</p>
                            </div>
                            <Button size="sm" variant="secondary" onClick={() => addSuggestion(s)}>
                              Add
                            </Button>
                          </div>
                        </li>
                      ))}
                    </ul>
                    <Button
                      className="mt-3 w-full gap-2"
                      variant="outline"
                      onClick={() =>
                        addQuests.mutate(
                          guide.data.suggestions.map((s) => ({
                            title: s.title,
                            category: s.category,
                            difficulty: s.difficulty,
                            source: "ai",
                          })),
                        )
                      }
                    >
                      <Sparkles className="size-4" aria-hidden /> Add all
                    </Button>
                  </div>
                ) : null}
              </div>
            ) : (
              <p className="text-muted-foreground mt-4 text-sm">
                Your coach is resting. Complete a quest and refresh.
              </p>
            )}
          </section>

          {usualQuests.length ? (
            <section className="panel p-5">
              <h2 className="text-lg">⚡ Your usual quests</h2>
              <p className="text-muted-foreground mt-1 text-sm">
                Detected from what you actually repeat.
              </p>
              <ul className="mt-3 space-y-2">
                {usualQuests.map((q) => (
                  <li
                    key={q.title}
                    className="bg-secondary/40 flex items-center justify-between gap-2 rounded-xl p-3"
                  >
                    <div>
                      <p className="text-sm font-medium">
                        {categoryEmoji(q.category)} {q.title}
                      </p>
                      <p className="text-muted-foreground text-xs">
                        {q.days} days in the last 3 weeks
                      </p>
                    </div>
                    <Button
                      size="sm"
                      variant="secondary"
                      onClick={() =>
                        addQuests.mutate([
                          {
                            title: q.title,
                            category: q.category,
                            difficulty: q.difficulty as NewQuest["difficulty"],
                            source: "routine",
                          },
                        ])
                      }
                    >
                      Add
                    </Button>
                  </li>
                ))}
              </ul>
              <Button
                variant="outline"
                className="mt-3 w-full"
                onClick={() =>
                  addQuests.mutate(
                    usualQuests.map((q) => ({
                      title: q.title,
                      category: q.category,
                      difficulty: q.difficulty as NewQuest["difficulty"],
                      source: "routine",
                    })),
                  )
                }
              >
                Add all
              </Button>
            </section>
          ) : null}

          {goals.length ? (
            <section className="panel p-5">
              <h2 className="text-lg">🎯 Goals</h2>
              <ul className="mt-3 space-y-3">
                {goals.map((g) => {
                  const percent = Math.min(
                    100,
                    Math.round((g.completed_quests / Math.max(1, g.target_quests)) * 100),
                  );
                  return (
                    <li key={g.id}>
                      <div className="flex justify-between text-sm">
                        <span>
                          {g.emoji} {g.title}
                        </span>
                        <span className="text-muted-foreground">{percent}%</span>
                      </div>
                      <div className="bg-secondary/70 mt-1 h-2 overflow-hidden rounded-full">
                        <div
                          className="bg-accent h-full rounded-full transition-[width] duration-500"
                          style={{ width: `${percent}%` }}
                        />
                      </div>
                    </li>
                  );
                })}
              </ul>
            </section>
          ) : null}
        </div>
      </div>
    </div>
  );
}
