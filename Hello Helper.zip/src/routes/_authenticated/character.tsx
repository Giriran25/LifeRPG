import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";

import { PlayerHeader } from "@/components/game/PlayerHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { getPlayerState, updateProfile } from "@/lib/player.functions";

export const Route = createFileRoute("/_authenticated/character")({
  head: () => ({
    meta: [
      { title: "Your Character — Life RPG" },
      {
        name: "description",
        content: "Customize your adventurer name, avatar, time zone and leaderboard visibility.",
      },
      { property: "og:title", content: "Your Character — Life RPG" },
      { property: "og:description", content: "Customize your adventurer." },
    ],
  }),
  component: Character,
});

const AVATARS = ["🧝", "🧙", "🛡️", "🏹", "⚔️", "🐉", "🦊", "🦉", "🌙", "🔥", "🌱", "🎯"];

function Character() {
  const qc = useQueryClient();
  const state = useQuery({ queryKey: ["player"], queryFn: () => getPlayerState() });
  const [name, setName] = useState<string | null>(null);

  const save = useMutation({
    mutationFn: (patch: { display_name?: string; avatar_emoji?: string; is_public?: boolean }) =>
      updateProfile({ data: patch }),
    onSuccess: () => {
      toast.success("Character updated.");
      void qc.invalidateQueries({ queryKey: ["player"] });
      void qc.invalidateQueries({ queryKey: ["leaderboard"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (state.isLoading || !state.data?.profile) return <Skeleton className="h-96 w-full rounded-2xl" />;
  const profile = state.data.profile;
  const nameValue = name ?? profile.display_name;

  return (
    <div className="space-y-6">
      <h1 className="display text-2xl">Your Character</h1>
      <PlayerHeader profile={profile} />

      <section className="panel space-y-6 p-5">
        <div className="space-y-2">
          <Label htmlFor="display-name">Adventurer name</Label>
          <div className="flex gap-2">
            <Input
              id="display-name"
              value={nameValue}
              maxLength={32}
              onChange={(e) => setName(e.target.value)}
            />
            <Button
              disabled={nameValue.trim().length < 2 || nameValue === profile.display_name}
              onClick={() => save.mutate({ display_name: nameValue.trim() })}
            >
              Save
            </Button>
          </div>
        </div>

        <div className="space-y-2">
          <Label>Avatar</Label>
          <ul className="flex flex-wrap gap-2">
            {AVATARS.map((emoji) => (
              <li key={emoji}>
                <button
                  type="button"
                  aria-label={`Choose avatar ${emoji}`}
                  aria-pressed={profile.avatar_emoji === emoji}
                  className={`bg-secondary/50 hover:bg-secondary flex size-12 items-center justify-center rounded-xl text-xl transition ${
                    profile.avatar_emoji === emoji ? "ring-primary ring-2" : ""
                  }`}
                  onClick={() => save.mutate({ avatar_emoji: emoji })}
                >
                  {emoji}
                </button>
              </li>
            ))}
          </ul>
        </div>

        <div className="flex items-center justify-between gap-4">
          <div>
            <Label htmlFor="public-toggle">Show me on the global ranking</Label>
            <p className="text-muted-foreground mt-1 text-sm">
              Turn this off to keep your progress private.
            </p>
          </div>
          <Switch
            id="public-toggle"
            checked={profile.is_public}
            onCheckedChange={(checked) => save.mutate({ is_public: checked })}
          />
        </div>

        <p className="text-muted-foreground text-sm">
          Time zone: <strong>{profile.timezone}</strong> — your day boundaries and streaks follow it.
        </p>
      </section>
    </div>
  );
}
