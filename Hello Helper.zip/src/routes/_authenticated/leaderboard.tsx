import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";

import { Reveal } from "@/components/game/Reveal";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { formatNumber } from "@/lib/game";
import { getLeaderboard } from "@/lib/player.functions";

export const Route = createFileRoute("/_authenticated/leaderboard")({
  head: () => ({
    meta: [
      { title: "Global Ranking — Life RPG" },
      {
        name: "description",
        content: "Weekly, monthly and all-time XP rankings across every Life RPG adventurer.",
      },
      { property: "og:title", content: "Global Ranking — Life RPG" },
      { property: "og:description", content: "See where you stand this week." },
    ],
  }),
  component: Leaderboard,
});

const MEDALS = ["🥇", "🥈", "🥉"];

function Leaderboard() {
  const [period, setPeriod] = useState<"week" | "month" | "all">("week");
  const board = useQuery({
    queryKey: ["leaderboard", period],
    queryFn: () => getLeaderboard({ data: { period } }),
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="display text-2xl">🌎 Global Ranking</h1>
        <p className="text-muted-foreground mt-1 text-sm">
          Only players who keep their profile public appear here.
        </p>
      </div>

      <Tabs value={period} onValueChange={(v) => setPeriod(v as typeof period)}>
        <TabsList>
          <TabsTrigger value="week">This week</TabsTrigger>
          <TabsTrigger value="month">This month</TabsTrigger>
          <TabsTrigger value="all">All time</TabsTrigger>
        </TabsList>
      </Tabs>

      {board.isLoading || !board.data ? (
        <Skeleton className="h-96 w-full rounded-2xl" />
      ) : board.data.rows.length === 0 ? (
        <div className="panel p-10 text-center">
          <p className="display text-lg">The arena is empty.</p>
          <p className="text-muted-foreground mt-2 text-sm">
            Complete a quest to put yourself on the board.
          </p>
        </div>
      ) : (
        <ol className="space-y-2">
          {board.data.rows.map((row, i) => {
            const isMe = row.user_id === board.data.me;
            return (
              <Reveal
                as="li"
                key={row.user_id}
                delay={Math.min(i, 12) * 55}
                className={`panel flex items-center gap-3 p-4 ${isMe ? "glow-gold" : ""}`}
              >
                <span className="display w-10 shrink-0 text-center text-lg">
                  {MEDALS[i] ?? i + 1}
                </span>
                <span className="bg-secondary/60 flex size-10 items-center justify-center rounded-xl text-lg">
                  {row.avatar_emoji}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate font-medium">
                    {row.display_name}
                    {isMe ? <span className="text-primary ml-2 text-xs">you</span> : null}
                  </p>
                  <p className="text-muted-foreground text-xs">
                    Level {row.level} · {row.title} · 🔥 {row.streak}
                  </p>
                </div>
                <span className="display text-primary shrink-0">{formatNumber(row.score)} XP</span>
              </Reveal>
            );
          })}
        </ol>
      )}
    </div>
  );
}
