import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { Flame, Sparkles, Swords, Trophy, Users, Zap } from "lucide-react";

import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Life RPG — Turn Your Goals Into Quests" },
      {
        name: "description",
        content:
          "Convert real-life goals into quests, earn XP and gold, level up, keep streaks alive, unlock badges and get AI coaching that adapts to you.",
      },
      { property: "og:title", content: "Life RPG — Turn Your Goals Into Quests" },
      {
        property: "og:description",
        content:
          "A gamified productivity RPG: quests, XP, levels, streaks, badges, leaderboards and an AI coach.",
      },
    ],
  }),
  component: Landing,
});

const features = [
  {
    icon: Swords,
    title: "Quests, not chores",
    body: "Every goal becomes a mission with XP, gold and difficulty. Rewards are calculated on the server.",
  },
  {
    icon: Sparkles,
    title: "An AI coach that knows you",
    body: "Suggestions built from your real history: routines, missed quests, categories you're neglecting.",
  },
  {
    icon: Flame,
    title: "Streaks that survive real life",
    body: "One streak day per day, timezone-aware, with shields you can buy for a missed day.",
  },
  {
    icon: Trophy,
    title: "Badges and milestones",
    body: "Quest counts, XP tiers, streak milestones and level titles — all unlocked automatically.",
  },
  {
    icon: Users,
    title: "Guilds and challenges",
    body: "Join communities, post progress, react, and compete in time-boxed challenges.",
  },
  {
    icon: Zap,
    title: "A year of proof",
    body: "A heatmap of every productive day, weekly summaries and honest pattern insights.",
  },
];

function Landing() {
  const { session, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && session) void navigate({ to: "/adventure" });
  }, [loading, session, navigate]);

  return (
    <main className="mx-auto max-w-6xl px-4 py-16 sm:py-24">
      <section className="text-center">
        <p className="display text-primary text-xs tracking-[0.45em] uppercase">Life RPG</p>
        <h1 className="mx-auto mt-6 max-w-3xl text-4xl leading-tight sm:text-6xl">
          Make progress feel like <span className="text-primary">levelling up</span>.
        </h1>
        <p className="text-muted-foreground mx-auto mt-6 max-w-2xl text-lg">
          Turn your real goals into quests. Earn XP and gold, hold a streak, unlock badges, climb the
          global ranking and let an AI coach plan your day from your own history.
        </p>
        <div className="mt-9 flex flex-wrap justify-center gap-3">
          <Button asChild size="lg">
            <Link to="/auth">Begin your adventure</Link>
          </Button>
          <Button asChild size="lg" variant="outline">
            <Link to="/auth" search={{ mode: "signin" }}>
              I already have a character
            </Link>
          </Button>
        </div>
      </section>

      <section className="panel mt-16 grid gap-4 p-6 sm:grid-cols-3">
        {[
          { label: "Quest → XP → Level", value: "⚔️" },
          { label: "Streak → Milestone → Badge", value: "🔥" },
          { label: "Ranking → Community → Motivation", value: "🌎" },
        ].map((s) => (
          <div key={s.label} className="text-center">
            <div className="text-3xl">{s.value}</div>
            <p className="text-muted-foreground mt-2 text-sm">{s.label}</p>
          </div>
        ))}
      </section>

      <section className="mt-16 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {features.map((f) => (
          <article key={f.title} className="panel p-5">
            <f.icon className="text-primary size-6" aria-hidden />
            <h2 className="mt-3 text-lg font-semibold">{f.title}</h2>
            <p className="text-muted-foreground mt-2 text-sm">{f.body}</p>
          </article>
        ))}
      </section>

      <footer className="text-muted-foreground mt-20 text-center text-sm">
        Built for people who want their effort to show up somewhere.
      </footer>
    </main>
  );
}
