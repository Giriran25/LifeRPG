import { useState } from "react";
import { Check, Loader2, Trash2 } from "lucide-react";

import { Button } from "@/components/ui/button";
import { categoryEmoji } from "@/lib/game";
import { cn } from "@/lib/utils";

export type Quest = {
  id: string;
  title: string;
  category: string;
  difficulty: string;
  status: string;
  xp_reward: number;
  gold_reward: number;
  quest_date: string;
  source: string;
};

const difficultyStyles: Record<string, string> = {
  easy: "text-chart-5 border-chart-5/40",
  medium: "text-accent border-accent/40",
  hard: "text-ember border-ember/40",
  epic: "text-arcane border-arcane/40",
};

export function QuestCard({
  quest,
  onComplete,
  onDelete,
  busy,
}: {
  quest: Quest;
  onComplete?: (quest: Quest) => void;
  onDelete?: (quest: Quest) => void;
  busy?: boolean;
}) {
  const [flying, setFlying] = useState(false);
  const done = quest.status === "completed";

  return (
    <li
      className={cn(
        "panel group relative flex items-center gap-3 p-4 transition-colors",
        done && "opacity-60",
      )}
    >
      <div className="bg-secondary/60 flex size-10 shrink-0 items-center justify-center rounded-xl text-lg">
        {categoryEmoji(quest.category)}
      </div>
      <div className="min-w-0 flex-1">
        <p className={cn("truncate font-medium", done && "line-through")}>{quest.title}</p>
        <div className="text-muted-foreground mt-1 flex flex-wrap items-center gap-2 text-xs">
          <span
            className={cn(
              "rounded-full border px-2 py-0.5 tracking-wide uppercase",
              difficultyStyles[quest.difficulty] ?? "",
            )}
          >
            {quest.difficulty}
          </span>
          <span>{quest.category}</span>
          <span className="text-primary">+{quest.xp_reward} XP</span>
          <span>💰 {quest.gold_reward}</span>
          {quest.source === "recovered" ? <span className="text-ember">recovered</span> : null}
        </div>
      </div>

      {flying ? (
        <span className="animate-xp-fly text-primary pointer-events-none absolute right-16 text-sm font-semibold">
          +{quest.xp_reward} XP
        </span>
      ) : null}

      {done ? (
        <span className="text-chart-5 flex items-center gap-1 text-sm">
          <Check className="size-4" aria-hidden /> Done
        </span>
      ) : (
        <div className="flex items-center gap-1">
          {onDelete ? (
            <Button
              size="icon"
              variant="ghost"
              aria-label={`Delete quest ${quest.title}`}
              onClick={() => onDelete(quest)}
            >
              <Trash2 className="size-4" aria-hidden />
            </Button>
          ) : null}
          {onComplete ? (
            <Button
              size="sm"
              disabled={busy}
              onClick={() => {
                setFlying(true);
                window.setTimeout(() => setFlying(false), 900);
                onComplete(quest);
              }}
            >
              {busy ? (
                <Loader2 className="size-4 animate-spin" aria-hidden />
              ) : (
                <Check className="size-4" aria-hidden />
              )}
              Complete
            </Button>
          ) : null}
        </div>
      )}
    </li>
  );
}
