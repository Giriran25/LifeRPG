import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from "react";

import { Button } from "@/components/ui/button";
import { ShareCard } from "@/components/game/ShareCard";

export type Badge = { code: string; name: string; emoji: string; description: string };

type Celebration = {
  kind: "level" | "badge" | "milestone";
  title: string;
  subtitle?: string;
  fromLevel?: number;
  toLevel?: number;
  badges?: Badge[];
  shareText?: string;
  stats?: { level: number; xp: number; streak: number };
};

type Ctx = { celebrate: (c: Celebration) => void };

const CelebrationContext = createContext<Ctx>({ celebrate: () => {} });

export function useCelebration() {
  return useContext(CelebrationContext);
}

export function CelebrationProvider({ children }: { children: ReactNode }) {
  const [queue, setQueue] = useState<Celebration[]>([]);
  const celebrate = useCallback((c: Celebration) => setQueue((q) => [...q, c]), []);
  const value = useMemo(() => ({ celebrate }), [celebrate]);
  const current = queue[0];

  return (
    <CelebrationContext.Provider value={value}>
      {children}
      {current ? (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={current.title}
          className="fixed inset-0 z-50 flex items-center justify-center bg-background/85 px-4 backdrop-blur-md"
        >
          <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
            {Array.from({ length: 14 }).map((_, i) => (
              <span
                key={i}
                className="animate-rise absolute bottom-0 text-2xl"
                style={{ left: `${(i * 7 + 4) % 100}%`, animationDelay: `${(i % 7) * 0.28}s` }}
              >
                {["✨", "⭐", "🔥", "💫"][i % 4]}
              </span>
            ))}
          </div>

          <div className="panel animate-pop-in relative w-full max-w-md p-6 text-center">
            {current.kind === "level" ? (
              <>
                <p className="display text-primary text-sm tracking-[0.35em] uppercase">Level Up</p>
                <div className="mt-4 flex items-center justify-center gap-4">
                  <span className="display text-4xl text-muted-foreground">{current.fromLevel}</span>
                  <span className="text-primary text-2xl">→</span>
                  <span className="display text-primary glow-gold rounded-xl px-4 py-2 text-5xl">
                    {current.toLevel}
                  </span>
                </div>
              </>
            ) : (
              <p className="display text-primary text-sm tracking-[0.35em] uppercase">
                {current.kind === "badge" ? "Badge Unlocked" : "Milestone"}
              </p>
            )}

            <h2 className="mt-4 text-2xl font-semibold">{current.title}</h2>
            {current.subtitle ? (
              <p className="text-muted-foreground mt-2 text-sm">{current.subtitle}</p>
            ) : null}

            {current.badges?.length ? (
              <div className="mt-5 flex flex-wrap justify-center gap-3">
                {current.badges.map((b) => (
                  <div key={b.code} className="panel w-32 p-3">
                    <div className="text-3xl">{b.emoji}</div>
                    <p className="mt-1 text-sm font-medium">{b.name}</p>
                    <p className="text-muted-foreground text-xs">{b.description}</p>
                  </div>
                ))}
              </div>
            ) : null}

            {current.stats ? (
              <div className="mt-6">
                <ShareCard
                  headline={current.title}
                  stats={current.stats}
                  quote={current.shareText ?? "Another mission complete."}
                />
              </div>
            ) : null}

            <Button className="mt-6 w-full" onClick={() => setQueue((q) => q.slice(1))} autoFocus>
              Continue the journey
            </Button>
          </div>
        </div>
      ) : null}
    </CelebrationContext.Provider>
  );
}
