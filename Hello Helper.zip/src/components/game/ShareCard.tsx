import { useCallback, useEffect, useRef, useState } from "react";
import { Copy, Download, Share2 } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { formatNumber } from "@/lib/game";
import { recordShare } from "@/lib/player.functions";

type Props = {
  headline: string;
  quote?: string;
  stats: { level: number; xp: number; streak: number };
  kind?: string;
};

const W = 1080;
const H = 1080;

function roundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

function wrap(ctx: CanvasRenderingContext2D, text: string, maxWidth: number) {
  const words = text.split(/\s+/);
  const lines: string[] = [];
  let line = "";
  for (const word of words) {
    const next = line ? `${line} ${word}` : word;
    if (ctx.measureText(next).width > maxWidth && line) {
      lines.push(line);
      line = word;
    } else {
      line = next;
    }
  }
  if (line) lines.push(line);
  return lines;
}

export function ShareCard({ headline, quote, stats, kind = "progress_card" }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const text = `${headline} — Level ${stats.level}, ${formatNumber(stats.xp)} XP, ${stats.streak} day streak on Life RPG. ${quote ?? ""}`.trim();

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    canvas.width = W;
    canvas.height = H;

    ctx.fillStyle = "#0a0a0f";
    ctx.fillRect(0, 0, W, H);

    const glowA = ctx.createRadialGradient(W * 0.85, H * 0.12, 0, W * 0.85, H * 0.12, W * 0.7);
    glowA.addColorStop(0, "rgba(150, 90, 255, 0.45)");
    glowA.addColorStop(1, "rgba(10, 10, 15, 0)");
    ctx.fillStyle = glowA;
    ctx.fillRect(0, 0, W, H);

    const glowB = ctx.createRadialGradient(W * 0.1, H * 0.92, 0, W * 0.1, H * 0.92, W * 0.6);
    glowB.addColorStop(0, "rgba(255, 190, 80, 0.32)");
    glowB.addColorStop(1, "rgba(10, 10, 15, 0)");
    ctx.fillStyle = glowB;
    ctx.fillRect(0, 0, W, H);

    ctx.strokeStyle = "rgba(255,255,255,0.14)";
    ctx.lineWidth = 3;
    roundRect(ctx, 44, 44, W - 88, H - 88, 48);
    ctx.stroke();

    ctx.fillStyle = "#f4c168";
    ctx.font = "600 34px Sora, system-ui, sans-serif";
    ctx.letterSpacing = "12px";
    ctx.fillText("LIFE RPG", 100, 160);
    ctx.letterSpacing = "0px";

    ctx.fillStyle = "#ffffff";
    ctx.font = "700 78px Cinzel, Georgia, serif";
    const lines = wrap(ctx, headline, W - 220).slice(0, 4);
    lines.forEach((line, i) => ctx.fillText(line, 100, 300 + i * 96));

    let y = 300 + lines.length * 96 + 40;
    if (quote) {
      ctx.fillStyle = "rgba(255,255,255,0.66)";
      ctx.font = "italic 40px Sora, system-ui, sans-serif";
      const qlines = wrap(ctx, `“${quote}”`, W - 220).slice(0, 3);
      qlines.forEach((line, i) => ctx.fillText(line, 100, y + i * 56));
      y += qlines.length * 56;
    }

    const boxY = H - 300;
    ctx.fillStyle = "rgba(255,255,255,0.06)";
    roundRect(ctx, 100, boxY, W - 200, 200, 36);
    ctx.fill();

    const cells: Array<[string, string, string]> = [
      ["LEVEL", String(stats.level), "#f4c168"],
      ["XP", formatNumber(stats.xp), "#ffffff"],
      ["STREAK", `${stats.streak}🔥`, "#ff8a4c"],
    ];
    const cellW = (W - 200) / 3;
    ctx.textAlign = "center";
    cells.forEach(([label, value, color], i) => {
      const cx = 100 + cellW * i + cellW / 2;
      ctx.fillStyle = color;
      ctx.font = "700 74px Cinzel, Georgia, serif";
      ctx.fillText(value, cx, boxY + 108);
      ctx.fillStyle = "rgba(255,255,255,0.55)";
      ctx.font = "600 26px Sora, system-ui, sans-serif";
      ctx.letterSpacing = "6px";
      ctx.fillText(label, cx, boxY + 156);
      ctx.letterSpacing = "0px";
    });
    ctx.textAlign = "left";

    setPreview(canvas.toDataURL("image/png"));
  }, [headline, quote, stats.level, stats.streak, stats.xp]);

  useEffect(() => {
    draw();
  }, [draw]);

  async function toBlob() {
    const canvas = canvasRef.current;
    if (!canvas) return null;
    return await new Promise<Blob | null>((resolve) =>
      canvas.toBlob((blob) => resolve(blob), "image/png"),
    );
  }

  async function onShare() {
    setBusy(true);
    try {
      const blob = await toBlob();
      if (!blob) throw new Error("Could not render the card.");
      const file = new File([blob], "life-rpg.png", { type: "image/png" });

      if (
        typeof navigator !== "undefined" &&
        navigator.canShare?.({ files: [file] }) &&
        navigator.share
      ) {
        await navigator.share({ files: [file], title: "Life RPG", text });
        await recordShare({ data: { kind, platform: "native_share" } });
        toast.success("Card shared.");
        return;
      }
      onDownload(blob);
    } catch (error) {
      if ((error as Error)?.name === "AbortError") return;
      toast.error((error as Error).message || "Sharing failed.");
    } finally {
      setBusy(false);
    }
  }

  function onDownload(existing?: Blob) {
    void (async () => {
      const blob = existing ?? (await toBlob());
      if (!blob) return;
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "life-rpg-card.png";
      a.click();
      URL.revokeObjectURL(url);
      await recordShare({ data: { kind, platform: "image_download" } });
      toast.success("Card image saved. Post it anywhere.");
    })();
  }

  return (
    <div className="space-y-3">
      <canvas ref={canvasRef} className="hidden" aria-hidden />
      {preview ? (
        <img
          src={preview}
          alt={`Share card: ${headline}`}
          className="border-border/60 w-full rounded-2xl border"
        />
      ) : (
        <div className="bg-secondary/40 aspect-square w-full animate-pulse rounded-2xl" />
      )}

      <div className="flex flex-wrap gap-2">
        <Button size="sm" className="gap-2" disabled={busy} onClick={onShare}>
          <Share2 className="size-4" aria-hidden /> Share card
        </Button>
        <Button size="sm" variant="secondary" className="gap-2" onClick={() => onDownload()}>
          <Download className="size-4" aria-hidden /> Save image
        </Button>
        <Button
          size="sm"
          variant="outline"
          className="gap-2"
          onClick={async () => {
            await navigator.clipboard.writeText(text);
            toast.success("Text copied.");
          }}
        >
          <Copy className="size-4" aria-hidden /> Copy text
        </Button>
      </div>
      <p className="text-muted-foreground text-xs">
        Shares are recorded from your own action here — Life RPG can't verify posts on other
        platforms.
      </p>
    </div>
  );
}
