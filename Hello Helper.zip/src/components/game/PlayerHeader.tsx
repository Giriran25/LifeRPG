import { formatNumber, levelProgress } from "@/lib/game";

export type PlayerProfile = {
  display_name: string;
  title: string;
  avatar_emoji: string;
  xp: number;
  gold: number;
  level: number;
  current_streak: number;
  longest_streak: number;
  quests_completed: number;
};

export function XpBar({ xp, compact = false }: { xp: number; compact?: boolean }) {
  const p = levelProgress(xp);
  return (
    <div>
      <div
        className="bg-secondary/70 relative h-3 w-full overflow-hidden rounded-full"
        role="progressbar"
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={p.percent}
        aria-label={`Level ${p.level} progress`}
      >
        <div
          className="from-primary to-ember h-full rounded-full bg-gradient-to-r transition-[width] duration-700 ease-out"
          style={{ width: `${p.percent}%` }}
        />
      </div>
      {!compact ? (
        <div className="text-muted-foreground mt-2 flex justify-between text-xs">
          <span>
            {formatNumber(xp)} / {formatNumber(p.nextXp)} XP
          </span>
          <span>{formatNumber(p.remaining)} XP to level {p.level + 1}</span>
        </div>
      ) : null}
    </div>
  );
}

export function PlayerHeader({ profile }: { profile: PlayerProfile }) {
  return (
    <section className="panel p-5 sm:p-6">
      <div className="flex flex-wrap items-center gap-4">
        <div className="glow-gold bg-secondary/60 flex size-16 items-center justify-center rounded-2xl text-3xl">
          {profile.avatar_emoji}
        </div>
        <div className="min-w-0 flex-1">
          <h1 className="display truncate text-2xl">{profile.display_name}</h1>
          <p className="text-muted-foreground text-sm">
            Level {profile.level} · “{profile.title}”
          </p>
        </div>
        <dl className="grid grid-cols-3 gap-4 text-center sm:gap-6">
          <div>
            <dt className="text-muted-foreground text-[10px] tracking-widest uppercase">XP</dt>
            <dd className="display text-primary text-lg">{formatNumber(profile.xp)}</dd>
          </div>
          <div>
            <dt className="text-muted-foreground text-[10px] tracking-widest uppercase">Gold</dt>
            <dd className="display text-lg">💰 {formatNumber(profile.gold)}</dd>
          </div>
          <div>
            <dt className="text-muted-foreground text-[10px] tracking-widest uppercase">Streak</dt>
            <dd className="display text-ember text-lg">🔥 {profile.current_streak}</dd>
          </div>
        </dl>
      </div>
      <div className="mt-5">
        <XpBar xp={profile.xp} />
      </div>
    </section>
  );
}
