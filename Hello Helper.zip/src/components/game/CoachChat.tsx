import { useEffect, useRef, useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { MessageCircle, Send, X } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { chatWithCoach, type CoachMessage } from "@/lib/ai.functions";

const GREETING: CoachMessage = {
  role: "assistant",
  content:
    "I'm your guide. Ask me what to tackle next, or say “remind me” and I'll pull up the quests you left unfinished.",
};

export function CoachChat() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<CoachMessage[]>([GREETING]);
  const [input, setInput] = useState("");
  const listRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const nudged = useRef(false);

  const send = useMutation({
    mutationFn: (next: CoachMessage[]) => chatWithCoach({ data: { messages: next } }),
    onSuccess: (res) => {
      setMessages((prev) => [...prev, { role: "assistant", content: res.reply }]);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, send.isPending]);

  useEffect(() => {
    if (open) textareaRef.current?.focus();
    if (open && !nudged.current) {
      nudged.current = true;
      const next: CoachMessage[] = [
        {
          role: "user",
          content:
            "Give me a short motivating nudge and remind me of any quests I left unfinished from previous days.",
        },
      ];
      send.mutate(next);
    }
  }, [open, send]);

  function submit() {
    const text = input.trim();
    if (!text || send.isPending) return;
    const next = [...messages.filter((m) => m !== GREETING), { role: "user" as const, content: text }];
    setMessages((prev) => [...prev, { role: "user", content: text }]);
    setInput("");
    send.mutate(next);
  }

  return (
    <div className="fixed bottom-24 left-4 z-40 lg:bottom-6">
      {open ? (
        <div
          style={{ backgroundColor: "var(--card)" }}
          className="panel shadow-2xl animate-in fade-in slide-in-from-bottom-4 flex h-[26rem] w-[min(22rem,calc(100vw-2rem))] flex-col overflow-hidden">
          <div className="border-border/60 flex items-center gap-2 border-b px-4 py-3">
            <span className="text-xl" aria-hidden>
              🧙
            </span>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-medium">Your Guide</p>
              <p className="text-muted-foreground text-xs">Personal quest coach</p>
            </div>
            <Button variant="ghost" size="icon" aria-label="Close coach" onClick={() => setOpen(false)}>
              <X className="size-4" aria-hidden />
            </Button>
          </div>

          <div ref={listRef} className="flex-1 space-y-3 overflow-y-auto px-4 py-3">
            {messages.map((m, i) => (
              <div
                key={i}
                className={
                  m.role === "user"
                    ? "bg-primary text-primary-foreground ml-auto max-w-[85%] rounded-2xl px-3 py-2 text-sm"
                    : "text-foreground max-w-[92%] text-sm whitespace-pre-wrap"
                }
              >
                {m.role === "assistant" ? m.content.replace(/\*\*/g, "") : m.content}
              </div>
            ))}
            {send.isPending ? (
              <p className="text-muted-foreground animate-pulse text-sm">Thinking…</p>
            ) : null}
          </div>

          <div className="border-border/60 flex items-end gap-2 border-t px-3 py-3">
            <Textarea
              ref={textareaRef}
              value={input}
              rows={1}
              placeholder="Ask your guide…"
              className="max-h-24 min-h-9 resize-none"
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  submit();
                }
              }}
            />
            <Button size="icon" aria-label="Send" disabled={send.isPending} onClick={submit}>
              <Send className="size-4" aria-hidden />
            </Button>
          </div>
        </div>
      ) : (
        <Button
          size="lg"
          className="gap-2 rounded-full shadow-lg"
          onClick={() => setOpen(true)}
          aria-label="Open your guide"
        >
          <MessageCircle className="size-5" aria-hidden />
          <span className="hidden sm:inline">Your Guide</span>
        </Button>
      )}
    </div>
  );
}
