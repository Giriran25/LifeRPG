import { useState, type ReactNode } from "react";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { CATEGORIES, DIFFICULTY_XP, type Difficulty } from "@/lib/game";

export type NewQuest = {
  title: string;
  category: string;
  difficulty: Difficulty;
  goal_id?: string | null;
};

export function AddQuestDialog({
  onCreate,
  goals,
  trigger,
}: {
  onCreate: (quest: NewQuest) => void;
  goals: Array<{ id: string; title: string; emoji: string }>;
  trigger?: ReactNode;
}) {
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState<string>("General");
  const [difficulty, setDifficulty] = useState<Difficulty>("medium");
  const [goalId, setGoalId] = useState<string>("none");

  function submit() {
    if (title.trim().length < 2) return;
    onCreate({
      title: title.trim(),
      category,
      difficulty,
      goal_id: goalId === "none" ? null : goalId,
    });
    setTitle("");
    setOpen(false);
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{trigger ?? <Button>New quest</Button>}</DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="display">Forge a new quest</DialogTitle>
          <DialogDescription>
            Turn a real-life intention into today's mission. Rewards are set by difficulty.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="quest-title">Quest</Label>
            <Input
              id="quest-title"
              value={title}
              placeholder="Solve 2 binary search problems"
              onChange={(e) => setTitle(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") submit();
              }}
            />
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label>Category</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map((c) => (
                    <SelectItem key={c.name} value={c.name}>
                      {c.emoji} {c.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Difficulty</Label>
              <Select value={difficulty} onValueChange={(v) => setDifficulty(v as Difficulty)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {(Object.keys(DIFFICULTY_XP) as Difficulty[]).map((d) => (
                    <SelectItem key={d} value={d}>
                      {d} · +{DIFFICULTY_XP[d]} XP
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          {goals.length ? (
            <div className="space-y-2">
              <Label>Linked goal</Label>
              <Select value={goalId} onValueChange={setGoalId}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">No goal</SelectItem>
                  {goals.map((g) => (
                    <SelectItem key={g.id} value={g.id}>
                      {g.emoji} {g.title}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          ) : null}
        </div>
        <DialogFooter>
          <Button onClick={submit}>Add to today</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
