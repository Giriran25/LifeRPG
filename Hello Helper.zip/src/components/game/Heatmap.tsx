import { useMemo } from "react";

export type ActivityDay = {
  day: string;
  quests_completed: number;
  xp_earned: number;
  gold_earned: number;
};

const LEVEL_CLASSES = [
  "bg-secondary/50",
  "bg-chart-5/30",
  "bg-chart-5/55",
  "bg-primary/60",
  "bg-primary",
];

function intensity(xp: number) {
  if (xp <= 0) return 0;
  if (xp < 60) return 1;
  if (xp < 150) return 2;
  if (xp < 300) return 3;
  return 4;
}

export function Heatmap({
  activity,
  today,
  onSelect,
  selected,
}: {
  activity: ActivityDay[];
  today: string;
  onSelect: (day: string) => void;
  selected?: string | null;
}) {
  const { weeks, months } = useMemo(() => {
    const map = new Map(activity.map((a) => [a.day, a]));
    const end = new Date(`${today}T00:00:00Z`);
    // Align the grid so each column is a full week ending on the current weekday.
    const start = new Date(end);
    start.setUTCDate(start.getUTCDate() - 363);
    start.setUTCDate(start.getUTCDate() - start.getUTCDay());

    const cols: Array<Array<{ day: string; xp: number; count: number; future: boolean }>> = [];
    const monthLabels: Array<{ index: number; label: string }> = [];
    const cursor = new Date(start);
    let lastMonth = -1;
    while (cursor <= end) {
      const week: Array<{ day: string; xp: number; count: number; future: boolean }> = [];
      for (let d = 0; d < 7; d++) {
        const iso = cursor.toISOString().slice(0, 10);
        const row = map.get(iso);
        week.push({
          day: iso,
          xp: row?.xp_earned ?? 0,
          count: row?.quests_completed ?? 0,
          future: iso > today,
        });
        if (cursor.getUTCDate() <= 7 && cursor.getUTCMonth() !== lastMonth) {
          lastMonth = cursor.getUTCMonth();
          monthLabels.push({
            index: cols.length,
            label: cursor.toLocaleString("en-US", { month: "short", timeZone: "UTC" }),
          });
        }
        cursor.setUTCDate(cursor.getUTCDate() + 1);
      }
      cols.push(week);
    }
    return { weeks: cols, months: monthLabels };
  }, [activity, today]);

  return (
    <div className="space-y-2">
      <div className="overflow-x-auto pb-2">
        <div className="min-w-max">
          <div className="text-muted-foreground mb-1 flex gap-[3px] text-[10px]">
            {weeks.map((_, i) => {
              const label = months.find((m) => m.index === i);
              return (
                <span key={i} className="w-[11px] shrink-0">
                  {label ? label.label : ""}
                </span>
              );
            })}
          </div>
          <div className="flex gap-[3px]">
            {weeks.map((week, wi) => (
              <div key={wi} className="flex flex-col gap-[3px]">
                {week.map((cell) => (
                  <button
                    key={cell.day}
                    type="button"
                    disabled={cell.future}
                    onClick={() => onSelect(cell.day)}
                    aria-label={`${cell.day}: ${cell.count} quests, ${cell.xp} XP`}
                    title={`${cell.day} · ${cell.count} quests · ${cell.xp} XP`}
                    className={`size-[11px] rounded-[3px] transition-transform hover:scale-125 focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none ${
                      cell.future ? "opacity-20" : LEVEL_CLASSES[intensity(cell.xp)]
                    } ${selected === cell.day ? "ring-primary ring-2" : ""}`}
                  />
                ))}
              </div>
            ))}
          </div>
        </div>
      </div>
      <div className="text-muted-foreground flex items-center gap-2 text-xs">
        <span>Less</span>
        {LEVEL_CLASSES.map((c, i) => (
          <span key={i} className={`size-[11px] rounded-[3px] ${c}`} />
        ))}
        <span>More</span>
      </div>
    </div>
  );
}
